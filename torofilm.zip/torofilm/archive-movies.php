<?php get_header(); ?>
	<div class="bd">
		<div class="dfxc">
			<main class="main-site">
				<section class="section movies">
					<header class="section-header">
						<div class="rw alg-cr jst-sb">
							<h1 class="section-title"><?php echo lang_torofilm('Movies', 'txt_movies'); ?></h1>
						</div>
					</header>
					<?php 
				    if ( have_posts() ) : ?>
						<div class="aa-cn" id="aa-movies">
							<div id="movies-a" class="aa-tb hdd on">
								<ul class="post-lst rw sm rcl2 rcl3a rcl4b rcl3c rcl4d rcl6e">
									<?php
							        while ( have_posts() ) : the_post();
										get_template_part( 'public/partials/template/movies', 'main' );
							    	endwhile; ?>
								</ul>
							</div>
						</div>
						<nav class="navigation pagination">
							<?php torofilm_pagination() ?>
						</nav>
					<?php endif; wp_reset_query();  ?>
				</section>
			</main>
			<?php get_sidebar(); ?>
		</div>
	</div>
<?php get_footer(); ?>