#!/bin/sh

cd "$(dirname "$0")" && \
php -S localhost:8000
