<?php

$sidebar = (string) get_option('tp_layout_sidebar', 'NoSdbr');

if ($sidebar !== 'NoSdbr') {
    echo '<aside>';

    if (is_home()) {
        dynamic_sidebar('sidebar-home');
    } else if (is_page()) {
        dynamic_sidebar('sidebar-pages');
    } else if (is_category()) {
        dynamic_sidebar('sidebar-home');
    } else if (is_tax('episodes')) {
        dynamic_sidebar('sidebar-episodes');
    } else if (is_tax('seasons')) {
        dynamic_sidebar('sidebar-seasons');
    } else if (!is_null($post)) {
        if ($post->post_type == 'movies') {
            dynamic_sidebar('sidebar-movies');
        } else if ($post->post_type == 'series') {
            dynamic_sidebar('sidebar-series');
        } else if ($post->post_type == 'post') {
            dynamic_sidebar('sidebar-pages');
        }
    }

    echo '</aside>';
}
