<?php

get_header();

if (is_page()) {
?>
    <div class="Body Container">
        <div class="Content">
            <div class="Container">
                <div class="<?php sidebar_class(); ?>">
                    <main>
                        <section class="Page">
                            <?php

                            $name = get_the_title() ?? null;

                            if (!is_null($name)) {
                                echo sprintf('<div class="Top"> <h1> %1$s </h1> </div>', $name);
                            }

                            ?>
                            <div class="Description">
                                <?php the_content(); ?>
                            </div>
                        </section>
                    </main>

                    <?php get_sidebar(); ?>
                </div>
            </div>
        </div>
    </div>
<?php
}

get_footer();
