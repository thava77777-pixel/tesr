<?php

get_header();

if (is_single()) {
    $object = $wp_query->get_queried_object();

    switch ($object->post_type) {
        case 'movies':
            get_template_part('resources/views/indexes/sngl', 'mvs');

            break;

        case 'series':
            get_template_part('resources/views/indexes/sngl', 'srs');

            break;
    }
}

get_footer();
