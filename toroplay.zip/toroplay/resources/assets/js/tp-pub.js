var TTPLAY = (function () {

	const VERSION = toroplay.version;
	const NONCE = toroplay.nonce;
    const URL = toroplay.url;
    
	var _console = function () {
		console.log(
			`${'\n'} %c TOROPLAY v${VERSION} %c built with love ${'\n'}`,
			'color: #7289DA; background: #23272A; padding:4px 0;',
			'background: #FFFFFF; padding:4px 0;'
		);
	};

    var _posts = function () {
        var widgets = document.querySelectorAll('.TPostMv')
        
        window.addEventListener('resize', function (event) {
            widgets.forEach(element => {
                var px = element.getBoundingClientRect().left + element.offsetWidth / 1.5
                if (px > document.body.offsetWidth / 1.5) {
                    element.classList.add('tt-right')
                } else {
                    element.classList.remove('tt-right')
                }
            });
        });
        
        widgets.forEach(element => {
            var px = element.getBoundingClientRect().left + element.offsetWidth / 1.5
            if (px > document.body.offsetWidth / 1.5) {
                element.classList.add('tt-right')
            } else {
                element.classList.remove('tt-right')
            }
        });        
	};

    var _light = function () {
        var light = document.querySelector('.lgtbx-lnk');
        var lgtbx = document.querySelector('.lgtbx');

        if (light !== null) {
            window.addEventListener('keyup', function (event) {     
                if (event.keyCode == 27) {
                    var evt = document.querySelector('.lgtbx-on');
    
                    if (evt !== null) {
                        evt.classList.toggle('lgtbx-on');
                    }
                }       
            });

            light.addEventListener('click', function (event) {
                var body = document.body;
    
                body.classList.toggle('lgtbx-on');
            });
        }

        if (lgtbx !== null) {
            lgtbx.addEventListener('click', function (event) {
                var body = document.body;
    
                body.classList.toggle('lgtbx-on');
            });   
        }
    };

    var _player = function () {
		var player = document.getElementById('playback');

        if (player !== null) {   
            player.addEventListener('click', function (event) {
                var count = 0;

                var interval = setInterval(function() {
                    count++;
        
                    if (count == 5) {
                        document.getElementById('playback-time').innerHTML = 'Loading...';
        
						const element = document.createElement('iframe');
						const embed = event.target.parentNode.parentNode;

						element.src = player.dataset.url;
						element.width = 560;
						element.height = 315;

						element.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';

						element.setAttribute('frameborder', 0);
						element.setAttribute('allowfullscreen', 1);

                        var plyr = document.querySelector('[data-player]');
    
                        if (plyr !== null) {   
                            plyr.innerHTML = '';
                            plyr.appendChild(element);
                        }

						_options();
                        clearInterval(interval);
                    } else {
                        document.getElementById('playback-time').innerHTML = 5 - count + ' Loading player...';
                    }
        
                }, 1000);
            });
        } 
    };

    var _options = function () {
        var player = document.getElementById('playback');

        if (player !== null) {   
            return;
        }

		var options = document.querySelectorAll('[data-option]');

        options.forEach((element) => {
            element.addEventListener('click', function (event) {
                var mv = event.currentTarget;
                var mvop = mv.querySelector('button');

                if (mv !== null) {   
                    var tpnv = document.querySelectorAll('.optnslst > li > button');

                    if (!mvop.classList.contains('on')) {
                        tpnv.forEach((element) => {
                            element.classList.remove('on');
                        });
    
                        var plyr = document.querySelector('[data-player]');
    
                        if (plyr !== null) {   
                            var embed = plyr.firstChild;
                            embed.src = window.atob(mv.dataset.src);
                        }

                        mvop.classList.add('on');
                    }
                }

            });
        });
    };

    var _links = function () {
		var links = document.querySelectorAll('[data-link]');

        links.forEach((element) => {
            element.addEventListener('click', function (event) {
                var mv = event.currentTarget;

                if (mv !== null) {   
					window.open(window.atob(mv.dataset.url));
                }

            });
        });
    };

    var _seasons = function () {
		var seasons = document.querySelectorAll('[data-season]');

        seasons.forEach((element) => {
            element.addEventListener('click', function (event) {
                var mv = event.currentTarget;
                

                if (mv !== null) {  
                    var link = mv.querySelector('.AA-link');

                    if (!link.classList.contains('On')) {
                        var data = document.querySelectorAll('.AA-link');
    
                        data.forEach((element) => {
                            element.classList.remove('On');
                        });
    
                        link.classList.add('On');
                    } else {
                        link.classList.remove('On');
                    }
                }
            });
        });
    };
    
    var _tabs = function () {
		var tabs = document.querySelectorAll('[data-tab]');

        tabs.forEach((element) => {
            element.addEventListener('click', function (event) {
                var mv = event.currentTarget;
                
                var navs = document.querySelectorAll('.MovieTabNav > div');
                var mvTb = document.querySelectorAll('.MvTbCn');

                navs.forEach((element) => {
                    element.classList.remove('on');
                });

                mvTb.forEach((element) => {
                    element.classList.remove('on');
                });
                
                mv.classList.add('on');
                
                var evt = document.getElementById(mv.dataset.tab);

                if (evt !== null) {
                    evt.classList.add('on');
                }
            });
        });
    };

	return {
		init: function () {
			_console();

            _posts();
            
            _light();

            _player();
            _options();
            _links();

            _seasons();
            _tabs();
		}
	};
})();

/** Webpack */
if (typeof module !== 'undefined') {
	module.exports = TTPLAY;
}

/** Vanilla */
if (window.addEventListener) {
	window.addEventListener('ready', TTPLAY.init(), false);
} else {
	window.onload = TTPLAY.init();
}

