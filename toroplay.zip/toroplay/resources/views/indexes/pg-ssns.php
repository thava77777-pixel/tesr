<div class="Body Container">
    <div class="Content">
        <div class="Container">
            <div class="<?php sidebar_class(); ?>">
                <main>
                    <section>
                        <?php

                        $name = $args['name'] ?? null;

                        if (!is_null($name)) {
                            echo sprintf('<div class="Top"> <h1> %1$s </h1> </div>', $name);
                        }

                        ?>
                        <ul class="MovieList Rows AX A06 B04 C03 E20 NoLmtxt">
                            <?php

                            $taxonomy   = 'seasons';
                            $number     = (int) get_option('tp_pages_pg_pages', 24);

                            $paged      = (get_query_var('paged')) ? get_query_var('paged') : 1;
                            $offset     = ($paged > 0) ?  $number * ($paged - 1) : 1;
                            $max        = wp_count_terms($taxonomy, array('hide_empty' => false));
                            $totalpages = ceil($max / $number);

                            $seasons = get_terms([
                                'taxonomy'    => $taxonomy,
                                'orderby'     => 'id',
                                'order'       => 'DESC',
                                'hide_empty'  => false,
                                'number'      => $number,
                                'offset'      => $offset
                            ]);

                            if ($seasons) {
                                foreach ($seasons as $season) {
                                    $id = get_term_meta($season->term_id, 'tr_id_post', true);

                                    get_template_part('resources/views/components/ssns', 'rtcl', [
                                        'id' => $id,
                                        'term_id' => $season->term_id
                                    ]);
                                }
                            }

                            wp_reset_postdata();

                            ?>
                        </ul>
                    </section>

                    <nav class="navigation pagination" role="navigation" aria-label="pagination">
                        <h2 class="screen-reader-text"> </h2>
                        <div class="nav-links">
                            <?php

                            echo paginate_links(array(
                                'base'          => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
                                'format'        => 'pagination',
                                'current'       => max(1, $paged),
                                'total'         => $totalpages,
                                'prev_text'     => '<i class="fa-chevron-left"></i>',
                                'next_text'     => '<i class="fa-chevron-right"></i>',
                                'show_all'      => false,
                                'end_size'      => 3,
                                'mid_size'      => 0
                            ));

                            ?>
                        </div>
                    </nav>
                </main>

                <?php get_sidebar(); ?>
            </div>
        </div>
    </div>
</div>