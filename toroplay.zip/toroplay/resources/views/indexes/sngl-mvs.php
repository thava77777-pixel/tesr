<?php

$details = new TOROPLAY\components\movies($post->ID);
$details->set_views();

$pts = get_option('tp_images_pts_movies', 'w185');
$bds = get_option('tp_images_bds_movies', 'w300');

?>

<div class="Body Container">
    <div class="Content">
        <div class="Container">
            <article class="TPost Single">
                <header>
                    <h1 class="Title"><?php the_title(); ?></h1>

                    <?php

                    $original = $details->original();

                    if ($original->has) {
                        echo sprintf('<h2 class="SubTitle"> %1$s </h2>', $original->results);
                    }

                    ?>

                    <div class="Image">
                        <figure>
                            <?php echo $details->thumbnail($pts, get_the_title()); ?>
                        </figure>
                    </div>
                    <?php

                    $content = $details->content();

                    if ($content->has) {
                        echo sprintf('<div class="Description"> %1$s </div>', $content->results);
                    }

                    ?>
                </header>

                <footer class="ClFx">
                    <p class="Info">
                        <?php

                        $ranking = $details->ranking();

                        if ($ranking->has) {
                            echo sprintf('<span class="Rank fa-star far"> %1$s </span>', $ranking->results);
                        }

                        $minutes = $details->minutes();

                        if ($minutes->has) {
                            echo sprintf('<span class="Time fa-clock far"> %1$s </span>', $minutes->results);
                        }

                        $release = $details->release();

                        if ($release->has) {
                            echo sprintf('<span class="Date fa-calendar-alt far"> %1$s </span>', $release->results);
                        }

                        $views = $details->views();

                        if ($views->has) {
                            echo sprintf('<span class="View fa-eye"> %1$s %2$s</span>', number_format($views->results), __('Views', 'toroplay'));
                        }

                        ?>
                    </p>
                    <ul class="ListPOpt">
                        <?php

                        $facebook = 'https://www.facebook.com/sharer.php?u=' . get_the_permalink();
                        $twitter = 'https://twitter.com/intent/tweet?original_referer=' . get_the_permalink() . '&amp;text=' . get_the_title() . '&amp;tw_p=tweetbutton&amp;url=' . get_the_permalink();
                        $reddit = 'https://www.reddit.com/submit?url=' . get_the_permalink() . '&title=' . get_the_title();

                        ?>
                        <li>
                            <a href="#!" rel="nofollow noopener" class="Fcb fa-facebook-f fab" onclick="window.open('<?php echo $facebook; ?>', 'Facebook', 'toolbar=0, status=0, width=650, height=450');"></a>
                        </li>
                        <li>
                            <a href="#!" rel="nofollow noopener" class="Twt fa-twitter fab" onclick="window.open('<?php echo $twitter; ?>', 'Twitter', 'toolbar=0, status=0, width=650, height=450');"></a>
                        </li>
                        <li>
                            <a href="#!" rel="nofollow noopener" class="Twt fa-reddit fab" onclick="window.open('<?php echo $reddit; ?>', 'Reddit', 'toolbar=0, status=0, width=650, height=450');"></a>
                        </li>
                    </ul>
                </footer>

                <div class="TPostBg Objf">
                    <?php echo $details->backdrop($bds, get_the_title()); ?>
                </div>
            </article>

            <div class="<?php sidebar_class(); ?>">
                <main>
                    <?php

                    $videos = $details->format_videos();

                    if ($videos->has) {
                        $content = $videos->results;

                        $advertising = (bool) get_option('tp_player_advertising', false);
                        $advertising_code = (string) get_option('tp_player_advertising_code', false);

                        $fake       = (bool) get_option('tp_player_fake', false);
                        $fake_blank = (string) get_option('tp_player_fake_blank', false);
                        $fake_url   = (string) get_option('tp_player_fake_url', '');

                        echo '<div class="optns-bx">';

                        $index = 0;
                        foreach ($content as $k => $v) {
                            echo '<div class="drpdn" x-data="{ drpdn: false }">';
                            if ($index == 0) {
                                $subidex = 0;

                                echo '<button class="btn on" :class="{ ' . stripslashes("'Current': drpdn") . ' }" @click="drpdn = !drpdn"><span>' . $v['label'] . ' <span>' . __('Options', 'toroplay') . '</span></span><i class="fa-chevron-down" :class="{ ' . stripslashes("'fa-chevron-up': drpdn") . ' }"></i></button>';

                                echo '<ul class="optnslst" x-show="drpdn" @click.away="drpdn = false" x-cloak>';
                                foreach ($v['link'] as $z) {
                                    if ($subidex == 0) {
                                        $count = sprintf('%02d', $subidex + 1);

                                        echo '<li data-src="' . base64_encode(home_url('/?trembed=' . $z['opt'] . '&trid=' . $post->ID . '&trtype=1')) . '" data-lmt="' . $z['lmt'] . '" data-option> <button class="btn on"><span class="nmopt">' . $count . '</span><span>' . $v['label'] . ' <span>' . $z['qly'] . '</span></span></button> </li>';
                                        $subidex++;
                                    } else {
                                        $count = sprintf('%02d', $subidex + 1);

                                        echo '<li data-src="' . base64_encode(home_url('/?trembed=' . $z['opt'] . '&trid=' . $post->ID . '&trtype=1')) . '" data-lmt="' . $z['lmt'] . '" data-option> <button class="btn"><span class="nmopt">' . $count . '</span><span>' . $v['label'] . ' <span>' . $z['qly'] . '</span></span></button> </li>';
                                        $subidex++;
                                    }
                                }
                                echo '</ul>';
                            } else {
                                $subidex = 0;

                                echo '<button class="btn on" :class="{ ' . stripslashes("'Current': drpdn") . ' }" @click="drpdn = !drpdn"><span>' . $v['label'] . ' <span>' . __('Options', 'toroplay') . '</span></span><i class="fa-chevron-down" :class="{ ' . stripslashes("'fa-chevron-up': drpdn") . ' }"></i></button>';

                                echo '<ul class="optnslst" x-show="drpdn" @click.away="drpdn = false" x-cloak>';
                                foreach ($v['link'] as $z) {
                                    $count = sprintf('%02d', $subidex + 1);

                                    echo '<li data-src="' . base64_encode(home_url('/?trembed=' . $z['opt'] . '&trid=' . $post->ID . '&trtype=1')) . '" data-lmt="' . $z['lmt'] . '" data-option> <button class="btn"><span class="nmopt">' . $count . '</span><span>' . $v['label'] . ' <span>' . $z['qly'] . '</span></span></button> </li>';
                                    $subidex++;
                                }
                                echo '</ul>';
                            }
                            echo '</div>';

                            $index++;
                        }
                        echo '</div>';

                        echo '<div class="TPlayerCn BgA">';
                        echo '<div class="EcBgA">';
                        echo '<div class="TPlayer">';

                        $index = 0;
                        foreach ($content as $k => $v) {
                            if ($index == 0) {
                                foreach ($v['link'] as $k => $z) {
                                    if ($k == 0) {
                                        if ($advertising) {
                                            echo $advertising_code;
                                        }

                                        echo '<div class="TPlayerTb Current" data-player>';

                                        if ($fake) {
                                            $target = ($fake_blank) ? 'target="_blank"' : '';

                                            echo '<a id="playback" href="' . $fake_url . '" ' . $target . ' data-url="' . home_url('/?trembed=' . $z['opt'] . '&trid=' . $post->ID . '&trtype=1') . '"><div class="plyrbg">' . $details->backdrop('w780', get_the_title()) . '<span class="fa-play play-video"></span><div class="plyr-op"><span class="plyr-progress"><span><span class="screen-reader-text">10% progress</span></span></span><aside><span class="btn"><i class="fa-play"><span class="screen-reader-text">play</span></i></span><span class="btn"><i class="fa-volume-up"><span class="screen-reader-text">volume</span></i></span><span class="btn time" id="playback-time">0:00 / 1:52:20</span></aside><aside><span class="btn"><i class="fa-cog"><span class="screen-reader-text">settings</span></i></span><span class="btn"><i class="fa-expand"><span class="screen-reader-text">full</span></i></span></aside></div></div></a>';
                                        } else {
                                            echo '<iframe width="560" height="315" src="' . home_url('/?trembed=' . $z['opt'] . '&trid=' . $post->ID . '&trtype=1') . '" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';
                                        }

                                        echo '</div>';
                                    }
                                }
                            }
                        }


                        echo '<span class="fa-lightbulb fal lgtbx-lnk"></span>';

                        echo '</div>';
                        echo '</div>';
                        echo '</div>';

                        echo '<span class="lgtbx"></span>';
                    } else {
                        $trailer = $details->trailer();

                        if ($trailer->has) {
                            echo '<div class="TPlayerCn BgA">';
                            echo '<div class="EcBgA">';
                            echo '<div class="TPlayer">';

                            echo htmlspecialchars_decode($trailer->results);

                            echo '</div>';
                            echo '</div>';
                            echo '</div>';
                        }
                    }

                    $links = $details->format_links();

                    if ($links->has) {
                        echo '<div class="Wdgt">';
                        echo '<div class="Title">' . __('Links', 'toroplay') . '</div>';
                        echo '<div class="TPTblCn LnksTb">';
                        echo '<table>';

                        echo '<thead>';
                        echo '<tr>';
                        echo '<th>#</th>';
                        echo '<th>' . __('Server', 'toroplay') . '</th>';
                        echo '<th>' . __('Quality', 'toroplay') . '</th>';
                        echo '<th>' . __('Language', 'toroplay') . '</th>';
                        echo '</tr>';
                        echo '</thead>';


                        echo '<tbody>';

                        $content = $links->results;

                        $index = 0;
                        foreach ($content as $v) {
                            $count = sprintf('%02d', $index + 1);

                            echo '<tr>';
                            echo '<td> <span class="Num">' . $count . '</span> </td>';

                            if (!is_null($v['link']['hts'])) {
                                echo '<td> <a href="#!" data-url="' . base64_encode(home_url('/?trdownload=' . $v['link']['opt'] . '&trid=' . $post->ID . '&trtype=1')) . '" data-lmt="' . $v['link']['lmt'] . '" data-link> <span> <img src="https://s2.googleusercontent.com/s2/favicons?domain=' . $v['link']['hts'] . '" alt="' . $v['link']['hts'] . '">' . $v['link']['srv'] . ' </span> </a> </td>';
                            } else {
                                echo '<td> <a href="#!" data-url="' . base64_encode(home_url('/?trdownload=' . $v['link']['opt'] . '&trid=' . $post->ID . '&trtype=1')) . '" data-lmt="' . $v['link']['lmt'] . '" data-link> ' . $v['link']['srv'] . '</a> </td>';
                            }

                            echo '<td> <span class="badge ttu white-co primary-bg fwb pdx brd1 fz12 mgr mgb">' . $v['link']['qly'] . '</span> </td>';

                            echo '<td> ' . $v['label'] . ' </td>';
                            echo '</tr>';

                            $index++;
                        }

                        echo '</tbody>';

                        echo '</table>';
                        echo '</div>';
                        echo '</div>';
                    }

                    ?>

                    <div class="MovieInfo TPost Single">
                        <div class="MovieTabNav">
                            <div class="Lnk on" data-tab="MvTb-details"><?php echo __('Details', 'toroplay'); ?></div>
                            <div class="Lnk" data-tab="MvTb-cast"><?php echo __('Cast', 'toroplay'); ?></div>
                        </div>

                        <div class="MvTbCn on anmt" id="MvTb-details">
                            <ul class="InfoList">
                                <?php

                                $premiere = $details->premiere();

                                if ($premiere->has) {
                                    echo sprintf('<li class="fa-bullseye"><strong class="fwb">%1$s</strong> %2$s </li>', __('Premiere date', 'toroplay'), $premiere->results);
                                }

                                $director = $details->director();

                                if ($director->has) {
                                    echo sprintf('<li class="fa-bullseye"><strong class="fwb">%1$s</strong> %2$s </li>', __('Director', 'toroplay'), $director->results);
                                }

                                $genres = $details->genres();

                                if ($genres->has) {
                                    echo sprintf('<li class="fa-bullseye"><strong class="fwb">%1$s</strong> %2$s </li>', __('Genres', 'toroplay'), $genres->results);
                                }

                                $tags = $details->tags();

                                if ($tags->has) {
                                    echo sprintf('<li class="fa-bullseye"><strong class="fwb">%1$s</strong> %2$s </li>', __('Tags', 'toroplay'), $tags->results);
                                }

                                ?>
                            </ul>
                        </div>

                        <div class="MvTbCn anmt" id="MvTb-cast">
                            <ul class="ListCast Rows AF A06 B03 C02 D20 E02">
                                <?php

                                $casts = $details->casts_raw('w185');

                                if ($casts->has) {
                                    foreach ($casts->results as $result) {
                                        echo '<li> <a aria-label="' . $result['nme'] . '" href="' . $result['url'] . '"> <figure> <span class="Objf"> <img src="' . $result['src'] . '" alt="' . $result['nme'] . '"> </span> <figcaption> ' . $result['nme'] . ' </figcaption> </figure> </a> </li>';
                                    }
                                }

                                ?>
                            </ul>
                        </div>

                        <div class="TPostBg Objf">
                            <?php echo $details->backdrop($bds, get_the_title()); ?>
                        </div>
                    </div>

                    <?php

                    if (comments_open() || get_comments_number()) {
                        comments_template();
                    }

                    ?>
                </main>

                <?php get_sidebar(); ?>
            </div>
        </div>
    </div>
</div>