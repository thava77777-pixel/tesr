<?php

$term_id = get_queried_object_id();
$details = new TOROPLAY\components\seasons($term_id, $post->ID);

$details->set_views();

$pts = get_option('tp_images_pts_seasons', 'w185');
$bds = get_option('tp_images_bds_seasons', 'w300');

?>
<div class="Body Container">
    <div class="Content">
        <div class="Container">
            <article class="TPost Single">
                <header>
                    <?php

                    $season_number = $details->season_number();

                    if ($season_number->has) {
                        if ($season_number->results != 00) {
                            echo sprintf('<h1 class="Title"> %1$s - %2$s <span>%3$s </span> </h1>', get_the_title(), __('Season', 'toroplay'), $season_number->results);
                        } else {
                            echo sprintf('<h1 class="Title"> %1$s </h1>', get_the_title());
                        }
                    }

                    ?>

                    <h2 class="SubTitle">
                        <?php

                        $status = $details->status();

                        if ($status->has) {
                            echo sprintf('<span class="Qlty"> %1$s </span>', $status->results);
                        }

                        $number_of_episodes = $details->number_of_episodes();

                        if ($number_of_episodes->has) {
                            if ($number_of_episodes->results != 00) {
                                echo sprintf('<span class="ClB"> %1$s </span> %2$s', $number_of_episodes->results, __('Episodes', 'toroplay'));
                            } else {
                                echo sprintf('<span class="ClB"> %1$s </span> %2$s', __('N/A', 'toroplay'), __('Episodes', 'toroplay'));
                            }
                        }

                        ?>
                    </h2>
                    <div class="Image">
                        <figure>
                            <?php echo $details->thumbnail($pts, get_the_title()); ?>
                        </figure>
                    </div>
                    <?php

                    $overview = $details->overview();

                    if ($overview->has) {
                        echo sprintf('<div class="Description"> %1$s </div>', $overview->results);
                    }

                    ?>
                </header>
                <footer class="ClFx">
                    <p class="Info">
                        <?php

                        $minutes = $details->minutes();

                        if ($minutes->has) {
                            echo sprintf('<span class="Time fa-clock far"> %1$s </span>', $minutes->results);
                        }

                        $release = $details->release();

                        if ($release->has) {
                            echo sprintf('<span class="Date fa-calendar-alt far"> %1$s </span>', $release->results);
                        }

                        $views = $details->views();

                        if ($views->has) {
                            echo sprintf('<span class="View fa-eye"> %1$s %2$s</span>', number_format($views->results), __('Views', 'toroplay'));
                        }

                        ?>
                    </p>
                    <ul class="ListPOpt">
                        <?php

                        $facebook = 'https://www.facebook.com/sharer.php?u=' . esc_url(get_term_link($term_id));
                        $twitter = 'https://twitter.com/intent/tweet?original_referer=' . esc_url(get_term_link($term_id)) . '&amp;text=' . get_the_title() . '&amp;tw_p=tweetbutton&amp;url=' . esc_url(get_term_link($term_id));
                        $reddit = 'https://www.reddit.com/submit?url=' . esc_url(get_term_link($term_id)) . '&title=' . get_the_title();

                        ?>
                        <li>
                            <a href="#!" rel="nofollow noopener" class="Fcb fa-facebook-f fab" onclick="window.open('<?php echo $facebook; ?>', 'Facebook', 'toolbar=0, status=0, width=650, height=450');"></a>
                        </li>
                        <li>
                            <a href="#!" rel="nofollow noopener" class="Twt fa-twitter fab" onclick="window.open('<?php echo $twitter; ?>', 'Twitter', 'toolbar=0, status=0, width=650, height=450');"></a>
                        </li>
                        <li>
                            <a href="#!" rel="nofollow noopener" class="Twt fa-reddit fab" onclick="window.open('<?php echo $reddit; ?>', 'Reddit', 'toolbar=0, status=0, width=650, height=450');"></a>
                        </li>
                    </ul>
                </footer>
                <div class="TPostBg Objf">
                    <?php echo $details->backdrop($bds, get_the_title()); ?>
                </div>
            </article>

            <div class="<?php sidebar_class(); ?>">

                <main>
                    <div class="Wdgt">
                        <?php

                        $season_number = $details->season_number();

                        if ($season_number->has) {
                            if ($season_number->results != 00) {
                                echo sprintf('<div class="Title"> %1$s - %2$s <span> %3$s </span> </div>', get_the_title(), __('Season', 'toroplay'), $season_number->results);
                            } else {
                                echo sprintf('<div class="Title"> %1$s </div>', get_the_title());
                            }
                        }

                        ?>
                        <div class="TPTblCn LnksTb">
                            <table>
                                <tbody>
                                    <?php

                                    $number = get_term_meta($term_id, 'season_number', true);

                                    if (!$number) {
                                        $number = 'NOT EXISTS';
                                        $qs = 'compare';
                                    } else {
                                        $qs = 'value';
                                    }

                                    $episodes = get_terms('episodes', [
                                        'orderby' => 'meta_value_num',
                                        'order'         => 'ASC',
                                        'hide_empty'    => false,
                                        'meta_query' => array(
                                            'relation'  => 'AND',
                                            array(
                                                'key'     => 'episode_number',
                                                'compare' => 'EXISTS',
                                            ),
                                            array(
                                                'key'     => 'tr_id_post',
                                                'value'   => $post->ID
                                            ),
                                            array(
                                                'key'     => 'season_number',
                                                $qs       => $number
                                            ),
                                        )
                                    ]);

                                    if ($episodes) {
                                        echo '<table>';
                                        echo '<tbody>';

                                        foreach ($episodes as $k => $episode) {
                                            $name = $episode->name;
                                            $slug = esc_url(get_term_link($episode));

                                            $episode = new TOROPLAY\components\episodes($episode->term_id);

                                            $date = $episode->date();

                                            if ($date->has) {
                                                $date = $date->results;
                                            } else {
                                                $date = '';
                                            }

                                            $formats = $episode->formats();


                                            if ($formats->has) {
                                                $formats = $formats->results;
                                            } else {
                                                $formats = '';
                                            }

                                            $pts = get_option('tp_images_pts_episodes', 'w185');

                                            echo '<tr><td><span class="Num">' . $formats . '</span></td><td class="MvTbImg B"><a href="' . $slug . '" class="MvTbImg">' . $episode->thumbnail($pts, $name) . '</a></td><td class="MvTbTtl"><a href="' . $slug . '">' . $name . '</a><span>' . $date . '</span></td><td class="MvTbPly"><a href="' . $slug . '" class="fa-play ClA"></a></td></tr>';
                                        }

                                        echo '</tbody>';
                                        echo '</table>';
                                    }

                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </main>

                <?php get_sidebar(); ?>
            </div>
        </div>
    </div>
</div>