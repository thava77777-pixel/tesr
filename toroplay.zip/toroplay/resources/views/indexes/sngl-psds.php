<?php

$term_id = get_queried_object_id();
$details = new TOROPLAY\components\episodes($term_id, $post->ID);

$details->set_views();

$bds = get_option('tp_images_bds_episodes', 'w300');

?>
<div class="Body Container">
    <div class="Content">
        <div class="Container">
            <div class="<?php sidebar_class(); ?>">
                <main>
                    <article class="TPost Single Episode">
                        <header>
                            <?php

                            $season_number = $details->season_number();
                            $episode_number = $details->episode_number();

                            if ($season_number->has and $episode_number->has) {
                                if ($season_number->results != 00) {
                                    echo sprintf('<h1 class="Title"> %1$s <span>%2$sx%3$s</span></h1>', get_the_title(), $season_number->results, $episode_number->results);
                                } else {
                                    echo sprintf('<h1 class="Title"> %1$s <span>%2$s</span></h1>', get_the_title(), $episode_number->results);
                                }
                            }

                            $name = $details->name();

                            if ($name->has) {
                                echo sprintf('<h2 class="SubTitle"> %1$s </h2>', $name->results);
                            }

                            $seasons = get_terms([
                                'taxonomy' => 'seasons',
                                'orderby' => 'term_id',
                                'meta_key' => 'tr_id_post',
                                'meta_value' => $post->ID
                            ]);

                            if ($seasons and count($seasons) > 1) {
                                echo '<div class="Select-Season">';
                                echo '<div class="drpdn" x-data="{ drpdn: false }">';

                                foreach ($seasons as $k => $season) {
                                    $current = sprintf('%02d', get_term_meta($term_id, 'season_number', true));
                                    $selects = sprintf('%02d', get_term_meta($season->term_id, 'season_number', true));

                                    if ($current == $selects) {
                                        echo sprintf('<button class="btn" :class="{' . stripslashes("'Current': drpdn ") . '}" @click="drpdn = !drpdn"> <span>%1$s %2$s <span>%3$s %4$s</span></span> <i class="fa-chevron-down" :class="{ ' . stripslashes("'fa-chevron-up': drpdn") . ' }"></i> </button>', __('Season', 'toroplay'), $selects, get_term_meta($season->term_id, 'number_of_episodes', true), __('Episodes', 'toroplay'));
                                    }
                                }

                                echo '<ul class="optnslst" x-show="drpdn" @click.away="drpdn = false" x-cloak>';
                                foreach ($seasons as $k => $season) {
                                    $current = sprintf('%02d', get_term_meta($term_id, 'season_number', true));
                                    $selects = sprintf('%02d', get_term_meta($season->term_id, 'season_number', true));

                                    if ($current != $selects) {
                                        echo sprintf('<li> <button class="btn" onclick="window.location.href = ' .  stripslashes("'" . get_term_link($season->term_id) . "'") . '"> <span>%1$s %2$s <span>%3$s %4$s</span></span> </button> </li>', __('Season', 'toroplay'), $selects, get_term_meta($season->term_id, 'number_of_episodes', true), __('Episodes', 'toroplay'));
                                    }
                                }
                                echo '</ul>';

                                echo '</div>';
                                echo '</div>';
                            }

                            $videos = $details->format_videos();

                            if ($videos->has) {
                                $content = $videos->results;

                                $advertising = (bool) get_option('tp_player_advertising', false);
                                $advertising_code = (string) get_option('tp_player_advertising_code', false);

                                $fake       = (bool) get_option('tp_player_fake', false);
                                $fake_blank = (string) get_option('tp_player_fake_blank', false);
                                $fake_url   = (string) get_option('tp_player_fake_url', '');

                                echo '<div class="optns-bx">';

                                $index = 0;
                                foreach ($content as $k => $v) {
                                    echo '<div class="drpdn" x-data="{ drpdn: false }">';
                                    if ($index == 0) {
                                        $subidex = 0;

                                        echo '<button class="btn" :class="{ ' . stripslashes("'Current': drpdn") . ' }" @click="drpdn = !drpdn"><span>' . $v['label'] . ' <span>' . __('Options', 'toroplay') . '</span></span><i class="fa-chevron-down" :class="{ ' . stripslashes("'fa-chevron-up': drpdn") . ' }"></i></button>';

                                        echo '<ul class="optnslst" x-show="drpdn" @click.away="drpdn = false" x-cloak>';
                                        foreach ($v['link'] as $z) {
                                            if ($subidex == 0) {
                                                $count = sprintf('%02d', $subidex + 1);

                                                echo '<li data-src="' . base64_encode(home_url('/?trembed=' . $z['opt'] . '&trid=' . $term_id . '&trtype=2')) . '" data-lmt="' . $z['lmt'] . '" data-option> <button class="btn on"><span class="nmopt">' . $count . '</span><span>' . $v['label'] . ' <span>' . $z['qly'] . '</span></span></button> </li>';
                                                $subidex++;
                                            } else {
                                                $count = sprintf('%02d', $subidex + 1);

                                                echo '<li data-src="' . base64_encode(home_url('/?trembed=' . $z['opt'] . '&trid=' . $term_id . '&trtype=2')) . '" data-lmt="' . $z['lmt'] . '" data-option> <button class="btn"><span class="nmopt">' . $count . '</span><span>' . $v['label'] . ' <span>' . $z['qly'] . '</span></span></button> </li>';
                                                $subidex++;
                                            }
                                        }
                                        echo '</ul>';
                                    } else {
                                        $subidex = 0;

                                        echo '<button class="btn" :class="{ ' . stripslashes("'Current': drpdn") . ' }" @click="drpdn = !drpdn"><span>' . $v['label'] . ' <span>' . __('Options', 'toroplay') . '</span></span><i class="fa-chevron-down" :class="{ ' . stripslashes("'fa-chevron-up': drpdn") . ' }"></i></button>';

                                        echo '<ul class="optnslst" x-show="drpdn" @click.away="drpdn = false" x-cloak>';
                                        foreach ($v['link'] as $z) {
                                            $count = sprintf('%02d', $subidex + 1);

                                            echo '<li data-src="' . base64_encode(home_url('/?trembed=' . $z['opt'] . '&trid=' . $term_id . '&trtype=2')) . '" data-lmt="' . $z['lmt'] . '" data-option> <button class="btn"><span class="nmopt">' . $count . '</span><span>' . $v['label'] . ' <span>' . $z['qly'] . '</span></span></button> </li>';
                                            $subidex++;
                                        }
                                        echo '</ul>';
                                    }
                                    echo '</div>';

                                    $index++;
                                }
                                echo '</div>';

                                echo '<div class="TPlayerCn BgA">';
                                echo '<div class="EcBgA">';

                                echo '<div class="TPlayer">';

                                $index = 0;
                                foreach ($content as $k => $v) {
                                    if ($index == 0) {
                                        foreach ($v['link'] as $k => $z) {
                                            if ($k == 0) {
                                                if ($advertising) {
                                                    echo $advertising_code;
                                                }

                                                echo '<div class="TPlayerTb Current" data-player>';

                                                if ($fake) {
                                                    $target = ($fake_blank) ? 'target="_blank"' : '';

                                                    echo '<a id="playback" href="' . $fake_url . '" ' . $target . ' data-url="' . home_url('/?trembed=' . $z['opt'] . '&trid=' . $term_id . '&trtype=2') . '"><div class="plyrbg">' . $details->backdrop('w780', get_the_title()) . '<span class="fa-play play-video"></span><div class="plyr-op"><span class="plyr-progress"><span><span class="screen-reader-text">10% progress</span></span></span><aside><span class="btn"><i class="fa-play"><span class="screen-reader-text">play</span></i></span><span class="btn"><i class="fa-volume-up"><span class="screen-reader-text">volume</span></i></span><span class="btn time" id="playback-time">0:00 / 1:52:20</span></aside><aside><span class="btn"><i class="fa-cog"><span class="screen-reader-text">settings</span></i></span><span class="btn"><i class="fa-expand"><span class="screen-reader-text">full</span></i></span></aside></div></div></a>';
                                                } else {
                                                    echo '<iframe width="560" height="315" src="' . home_url('/?trembed=' . $z['opt'] . '&trid=' . $term_id . '&trtype=2') . '" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';
                                                }

                                                echo '</div>';
                                            }
                                        }
                                    }
                                }

                                echo '<span class="fa-lightbulb fal lgtbx-lnk"></span>';
                                echo '</div>';

                                echo '</div>';
                                echo '</div>';

                                echo '<span class="lgtbx"></span>';
                            } else {
                                $trailer = $details->trailer();

                                if ($trailer->has) {
                                    echo '<div class="TPlayerCn BgA">';
                                    echo '<div class="EcBgA">';
                                    echo '<div class="TPlayer">';

                                    echo htmlspecialchars_decode($trailer->results);

                                    echo '</div>';
                                    echo '</div>';
                                    echo '</div>';
                                }
                            }

                            $current = get_term_meta($term_id, 'season_number', true);

                            if (!$current) {
                                $current = 'NOT EXISTS';
                                $qs = 'compare';
                            } else {
                                $qs = 'value';
                            }


                            $episodes = get_terms('episodes', array(
                                'orderby' => 'meta_value_num',
                                'order'         => 'ASC',
                                'hide_empty'    => false,
                                'meta_query' => array(
                                    'relation'  => 'AND',
                                    array(
                                        'key'     => 'episode_number',
                                        'compare' => 'EXISTS',
                                    ),
                                    array(
                                        'key'     => 'tr_id_post',
                                        'value'   => $post->ID
                                    ),
                                    array(
                                        'key'     => 'season_number',
                                        $qs       => $current
                                    )
                                )
                            ));

                            if ($episodes and count($episodes) > 1) {
                                echo '<div class="Season-EpisodesCn">';
                                echo '<div class="Season-Episodes Episodes" x-data="{swiper: null}" x-init="swiper = new Swiper($refs.container, { loop: true, spaceBetween: 10, autoHeight: true, slidesPerView: 1, breakpoints: { 450: { slidesPerView: 2, }, 768: { slidesPerView: 3, }, 1200: { slidesPerView: 4, }, } })">';

                                echo '<div class="swiper-container" x-ref="container">';
                                echo '<div class="swiper-wrapper">';

                                foreach ($episodes as $k => $episode) {
                                    $name = $episode->name;
                                    $term = $episode->term_id;

                                    $slug = esc_url(get_term_link($term));

                                    $episode = new TOROPLAY\components\episodes($term);

                                    $name = $episode->name();

                                    if ($name->has) {
                                        $name = $name->results;
                                    } else {
                                        $name = '';
                                    }

                                    $minutes = $episode->minutes();

                                    if ($minutes->has) {
                                        $minutes = $minutes->results;
                                    } else {
                                        $minutes = '';
                                    }

                                    $formats = $episode->formats();


                                    if ($formats->has) {
                                        $formats = $formats->results;
                                    } else {
                                        $formats = '';
                                    }

                                    if (!strlen($name) <= 20) {
                                        $format = explode('{unique.wordwrap}', wordwrap($name, 20, ' {unique.wordwrap} ', false));
                                        $name = isset($format[0]) ? $format[0] : '';
                                    }

                                    $season_number = $episode->season_number();
                                    $episode_number = $episode->episode_number();

                                    if ($season_number->has and $episode_number->has) {
                                        if ($season_number->results != 00) {
                                            $cv = $season_number->results . 'x' . $episode_number->results;
                                        } else {
                                            $cv = $episode_number->results;
                                        }
                                    } else {
                                        $cv = '';
                                    }

                                    $pts = get_option('tp_images_pts_episodes', 'w185');

                                    if ($term_id == $term) {
                                        echo '<div class="swiper-slide watching"><div class="TPostMv"><div class="TPost C"><a href="#!"><div class="Image"><figure class="Objf TpMvPlay fa-play">' . $episode->thumbnail($pts, $name) . ' <figcaption><span class="ClB">' . $cv . '</span> ' . $name . '</figcaption></figure></div></a></div></div></div>';
                                    } else {
                                        echo '<div class="swiper-slide"><div class="TPostMv"><div class="TPost C"><a href="' . $slug . '"><div class="Image"><figure class="Objf TpMvPlay fa-play">' . $episode->thumbnail($pts, $name) . ' <figcaption><span class="ClB">' . $cv . '</span> ' . $name . '</figcaption></figure></div></a></div></div></div>';
                                    }
                                }
                                echo '</div>';
                                echo '</div>';

                                echo '<button class="btn btn-nv-prev lg white-bg shdw pdx0 brdc bd0 text-co poa l0 t0 b0 h-48 mga z1" @click="swiper.slidePrev()"><i class="fa-chevron-left"></i></button>';
                                echo '<button class="btn btn-nv-next lg white-bg shdw pdx0 brdc bd0 text-co poa r0 t0 b0 h-48 mga z1" @click="swiper.slideNext()"><i class="fa-chevron-right"></i></button>';

                                echo '</div>';
                                echo '</div>';
                            }

                            $overview = $details->overview();

                            if ($overview->has) {
                                echo sprintf('<div class="Description"> %1$s </div>', $overview->results);
                            }

                            ?>
                        </header>
                        <footer class="ClFx">
                            <p class="Info">
                                <?php

                                $minutes = $details->minutes();

                                if ($minutes->has) {
                                    echo sprintf('<span class="Time fa-clock far"> %1$s </span>', $minutes->results);
                                }

                                $release = $details->release();

                                if ($release->has) {
                                    echo sprintf('<span class="Date fa-calendar-alt far"> %1$s </span>', $release->results);
                                }

                                $views = $details->views();

                                if ($views->has) {
                                    echo sprintf('<span class="View fa-eye"> %1$s %2$s</span>', number_format($views->results), __('Views', 'toroplay'));
                                }

                                ?>
                            </p>
                            <ul class="ListPOpt">
                                <?php

                                $facebook = 'https://www.facebook.com/sharer.php?u=' . esc_url(get_term_link($term_id));
                                $twitter = 'https://twitter.com/intent/tweet?original_referer=' . esc_url(get_term_link($term_id)) . '&amp;text=' . get_the_title() . '&amp;tw_p=tweetbutton&amp;url=' . esc_url(get_term_link($term_id));
                                $reddit = 'https://www.reddit.com/submit?url=' . esc_url(get_term_link($term_id)) . '&title=' . get_the_title();

                                ?>
                                <li>
                                    <a href="#!" rel="nofollow noopener" rel="nofollow noopener" class="Fcb fa-facebook-f fab" onclick="window.open('<?php echo $facebook; ?>', 'Facebook', 'toolbar=0, status=0, width=650, height=450');"></a>
                                </li>
                                <li>
                                    <a href="#!" rel="nofollow noopener" class="Twt fa-twitter fab" onclick="window.open('<?php echo $twitter; ?>', 'Twitter', 'toolbar=0, status=0, width=650, height=450');"></a>
                                </li>
                                <li>
                                    <a href="#!" rel="nofollow noopener" class="Twt fa-reddit fab" onclick="window.open('<?php echo $reddit; ?>', 'Reddit', 'toolbar=0, status=0, width=650, height=450');"></a>
                                </li>
                            </ul>
                        </footer>
                        <div class="TPostBg Objf">
                            <?php echo $details->backdrop($bds, get_the_title()); ?>
                        </div>
                    </article>

                    <div class="<?php sidebar_class(); ?>">
                        <?php

                        $links = $details->format_links();

                        if ($links->has) {
                            echo '<div class="Wdgt">';
                            echo '<div class="Title">' . __('Links', 'toroplay') . '</div>';
                            echo '<div class="TPTblCn LnksTb">';
                            echo '<table>';

                            echo '<thead>';
                            echo '<tr>';
                            echo '<th>#</th>';
                            echo '<th>' . __('Server', 'toroplay') . '</th>';
                            echo '<th>' . __('Quality', 'toroplay') . '</th>';
                            echo '<th>' . __('Language', 'toroplay') . '</th>';
                            echo '</tr>';
                            echo '</thead>';


                            echo '<tbody>';

                            $content = $links->results;

                            $index = 0;
                            foreach ($content as $v) {
                                $count = sprintf('%02d', $index + 1);

                                echo '<tr>';
                                echo '<td> <span class="Num">' . $count . '</span> </td>';

                                if (!is_null($v['link']['hts'])) {
                                    echo '<td> <a href="#!" data-url="' . base64_encode(home_url('/?trdownload=' . $v['link']['opt'] . '&trid=' . $term_id . '&t=ser')) . '" data-link> <span> <img src="https://s2.googleusercontent.com/s2/favicons?domain=' . $v['link']['hts'] . '" alt="' . $v['link']['hts'] . '">' . $v['link']['srv'] . ' </span> </a> </td>';
                                } else {
                                    echo '<td> <a href="#!" data-url="' . base64_encode(home_url('/?trdownload=' . $v['link']['opt'] . '&trid=' . $term_id . '&t=ser')) . '" data-link> ' . $v['link']['srv'] . '</a> </td>';
                                }

                                echo '<td> <span class="badge ttu white-co primary-bg fwb pdx brd1 fz12 mgr mgb">' . $v['link']['qly'] . '</span> </td>';

                                echo '<td> ' . $v['label'] . ' </td>';
                                echo '</tr>';

                                $index++;
                            }

                            echo '</tbody>';

                            echo '</table>';
                            echo '</div>';
                            echo '</div>';
                        }

                        ?>

                    </div>
                </main>

                <?php get_sidebar(); ?>
            </div>
        </div>
    </div>
</div>