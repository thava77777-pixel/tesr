<div class="Body Container">
    <div class="Content">
        <div class="Container">
            <div class="<?php sidebar_class(); ?>">
                <main>
                    <section class="Page">
                        <article class="news">
                            <?php

                            if (get_the_post_thumbnail($post->ID, 'original')) {
                                echo '<div class="pctr"> <figure> ' . get_the_post_thumbnail($post->ID, 'original') . ' </figure> </div>';
                            }

                            ?>
                            <header class="Top">
                                <h1 class="ttl"><?php the_title(); ?></h1>
                                <p class="meta">
                                    <span class="usr-nm"><span><?php echo get_the_author_meta('display_name', $post->post_author); ?></span> <?php echo get_the_date(); ?></span>
                                </p>
                            </header>

                            <div class="Description">
                                <?php the_content(); ?>
                            </div>

                            <div class="share-bx">
                                <div class="share-ttl"><?php echo __('SHARE ARTICLE', 'toroplay'); ?></div>
                                <ul class="ListPOpt">
                                    <?php

                                    $facebook = 'https://www.facebook.com/sharer.php?u=' . get_the_permalink();
                                    $twitter = 'https://twitter.com/intent/tweet?original_referer=' . get_the_permalink() . '&amp;text=' . get_the_title() . '&amp;tw_p=tweetbutton&amp;url=' . get_the_permalink();
                                    $reddit = 'https://www.reddit.com/submit?url=' . get_the_permalink() . '&title=' . get_the_title();

                                    ?>

                                    <li>
                                        <a href="#!" rel="nofollow noopener" rel="nofollow noopener" class="Fcb fa-facebook-f fab" onclick="window.open('<?php echo $facebook; ?>', 'Facebook', 'toolbar=0, status=0, width=650, height=450');"></a>
                                    </li>
                                    <li>
                                        <a href="#!" rel="nofollow noopener" class="Twt fa-twitter fab" onclick="window.open('<?php echo $twitter; ?>', 'Twitter', 'toolbar=0, status=0, width=650, height=450');"></a>
                                    </li>
                                    <li>
                                        <a href="#!" rel="nofollow noopener" class="Twt fa-reddit fab" onclick="window.open('<?php echo $reddit; ?>', 'Reddit', 'toolbar=0, status=0, width=650, height=450');"></a>
                                    </li>
                                </ul>
                            </div>
                        </article>
                    </section>

                    <?php

                    if (comments_open() || get_comments_number()) {
                        comments_template();
                    }

                    ?>

                </main>

                <?php get_sidebar(); ?>
            </div>
        </div>
    </div>
</div>