<div class="Body Container">
    <div class="Content">
        <div class="Container">
            <div class="<?php sidebar_class(); ?>">
                <main>
                    <section>
                        <?php

                        $name = $args['name'] ?? null;

                        if (!is_null($name)) {
                            echo sprintf('<div class="Top"> <h1> %1$s </h1> </div>', $name);
                        }

                        ?>
                        <ul class="MovieList Rows AF A06 B04 C03 E20">
                            <?php

                            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

                            query_posts([
                                'post_type'           => array('series'),
                                'post_status'         => 'publish',
                                'posts_per_page'      => (int) get_option('tp_pages_pg_pages', 24),
                                'ignore_sticky_posts' => true,
                                'paged'               => $paged
                            ]);

                            if (have_posts()) :
                                while (have_posts()) : the_post();
                                    get_template_part('resources/views/components/srs', 'rtcl');
                                endwhile;
                            endif;

                            ?>
                        </ul>
                    </section>

                    <?php

                    the_posts_pagination([
                        'screen_reader_text' => ' ',
                        'before_page_number' => '',
                        'prev_text' => '<i class="fa-chevron-left"></i>',
                        'next_text' => '<i class="fa-chevron-right"></i>',
                        'mid_size'  => 2,
                    ]);

                    ?>
                </main>

                <?php get_sidebar(); ?>
            </div>
        </div>
    </div>
</div>