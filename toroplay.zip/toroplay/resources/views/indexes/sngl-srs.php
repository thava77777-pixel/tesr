<?php

$details = new TOROPLAY\components\series($post->ID);
$details->set_views();

$pts = get_option('tp_images_pts_series', 'w185');
$bds = get_option('tp_images_bds_series', 'w300');

?>

<div class="Body Container">
    <div class="Content">
        <div class="Container">
            <article class="TPost Single">
                <header>
                    <h1 class="Title"><?php the_title(); ?></h1>
                    <h2 class="SubTitle">
                        <?php

                        $status = $details->status();

                        if ($status->has) {
                            echo sprintf('<span class="Qlty"> %1$s </span>', $status->results);
                        }

                        $seasons = $details->seasons();
                        $episodes = $details->episodes();

                        if ($seasons->has and $episodes->has) {
                            echo sprintf('<span class="ClB"> %1$s </span> %2$s - <span class="ClB"> %3$s </span> %4$s ', $seasons->results, __('Seasons', 'toroplay'), $episodes->results, __('Episodes', 'toroplay'));
                        }

                        ?>
                    </h2>
                    <div class="Image">
                        <figure>
                            <?php echo $details->thumbnail($pts, get_the_title()); ?>
                        </figure>
                    </div>
                    <div class="Description">
                        <?php

                        $content = $details->content();

                        if ($content->has) {
                            echo sprintf('<div class="Description"> %1$s </div>', $content->results);
                        }

                        ?>
                    </div>
                </header>

                <footer class="ClFx">
                    <p class="Info">
                        <?php

                        $ranking = $details->ranking();

                        if ($ranking->has) {
                            echo sprintf('<span class="Rank fa-star far"> %1$s </span>', $ranking->results);
                        }

                        $minutes = $details->minutes();

                        if ($minutes->has) {
                            echo sprintf('<span class="Time fa-clock far"> %1$s </span>', $minutes->results);
                        }

                        $release = $details->release();

                        if ($release->has) {
                            echo sprintf('<span class="Date fa-calendar-alt far"> %1$s </span>', $release->results);
                        }

                        $views = $details->views();

                        if ($views->has) {
                            echo sprintf('<span class="View fa-eye"> %1$s %2$s</span>', number_format($views->results), __('Views', 'toroplay'));
                        }

                        ?>
                    </p>
                    <ul class="ListPOpt">
                        <?php

                        $facebook = 'https://www.facebook.com/sharer.php?u=' . get_the_permalink();
                        $twitter = 'https://twitter.com/intent/tweet?original_referer=' . get_the_permalink() . '&amp;text=' . get_the_title() . '&amp;tw_p=tweetbutton&amp;url=' . get_the_permalink();
                        $reddit = 'https://www.reddit.com/submit?url=' . get_the_permalink() . '&title=' . get_the_title();

                        ?>
                        <li>
                            <a href="#!" rel="nofollow noopener" class="Fcb fa-facebook-f fab" onclick="window.open('<?php echo $facebook; ?>', 'Facebook', 'toolbar=0, status=0, width=650, height=450');"></a>
                        </li>
                        <li>
                            <a href="#!" rel="nofollow noopener" class="Twt fa-twitter fab" onclick="window.open('<?php echo $twitter; ?>', 'Twitter', 'toolbar=0, status=0, width=650, height=450');"></a>
                        </li>
                        <li>
                            <a href="#!" rel="nofollow noopener" class="Twt fa-reddit fab" onclick="window.open('<?php echo $reddit; ?>', 'Reddit', 'toolbar=0, status=0, width=650, height=450');"></a>
                        </li>
                    </ul>
                </footer>

                <div class="TPostBg Objf">
                    <?php echo $details->backdrop($bds, get_the_title()); ?>
                </div>
            </article>

            <div class="<?php sidebar_class(); ?>">
                <main>
                    <?php

                    $seasons = get_terms([
                        'taxonomy' => 'seasons',
                        'orderby' => 'term_id',
                        'meta_key' => 'tr_id_post',
                        'meta_value' => $post->ID
                    ]);

                    if ($seasons) {
                        foreach ($seasons as $k => $season) {
                            $name = $season->name;
                            $class = ($k == 0) ? 'On' : '';

                            echo '<div class="Wdgt AABox" data-season>';
                            echo '<div class="Title AA-link ' . $class . '">' . $name . ' <i class="Vmrls ClA fa-chevron-down"></i> </div>';

                            echo '<div class="TPTblCn LnksTb AA-cont">';

                            $number = get_term_meta($season->term_id, 'season_number', true);

                            if (!$number) {
                                $number = 'NOT EXISTS';
                                $qs = 'compare';
                            } else {
                                $qs = 'value';
                            }

                            $episodes = get_terms('episodes', array(
                                'orderby' => 'meta_value_num',
                                'order'         => 'ASC',
                                'hide_empty'    => false,
                                'meta_query' => array(
                                    'relation'  => 'AND',
                                    array(
                                        'key'     => 'episode_number',
                                        'compare' => 'EXISTS',
                                    ),
                                    array(
                                        'key'     => 'tr_id_post',
                                        'value'   => $post->ID
                                    ),
                                    array(
                                        'key'     => 'season_number',
                                        $qs       => $number
                                    )
                                )
                            ));

                            if ($episodes) {
                                echo '<table>';
                                echo '<tbody>';

                                foreach ($episodes as $k => $episode) {
                                    $name = $episode->name;
                                    $slug = esc_url(get_term_link($episode));

                                    $episode = new TOROPLAY\components\episodes($episode->term_id);

                                    $date = $episode->date();

                                    if ($date->has) {
                                        $date = $date->results;
                                    } else {
                                        $date = '';
                                    }

                                    $formats = $episode->formats();


                                    if ($formats->has) {
                                        $formats = $formats->results;
                                    } else {
                                        $formats = '';
                                    }

                                    $pts = get_option('tp_images_pts_episodes', 'w185');

                                    echo '<tr><td><span class="Num">' . $formats . '</span></td><td class="MvTbImg B"><a href="' . $slug . '" class="MvTbImg">' . $episode->thumbnail($pts, $name) . '</a></td><td class="MvTbTtl"><a href="' . $slug . '">' . $name . '</a><span>' . $date . '</span></td><td class="MvTbPly"><a href="' . $slug . '" class="fa-play ClA"></a></td></tr>';
                                }

                                echo '</tbody>';
                                echo '</table>';
                            }

                            echo '</div>';
                            echo '</div>';
                        }
                    }

                    ?>

                    <div class="MovieInfo TPost Single">
                        <div class="MovieTabNav">
                            <div class="Lnk on" data-tab="MvTb-details"><?php echo __('Details', 'toroplay'); ?></div>
                            <div class="Lnk" data-tab="MvTb-cast"><?php echo __('Cast', 'toroplay'); ?></div>
                        </div>

                        <div class="MvTbCn on anmt" id="MvTb-details">
                            <ul class="InfoList">
                                <?php

                                $director = $details->director();

                                if ($director->has) {
                                    echo sprintf('<li class="fa-bullseye"><strong class="fwb">%1$s</strong> %2$s </li>', __('Director', 'toroplay'), $director->results);
                                }

                                $genres = $details->genres();

                                if ($genres->has) {
                                    echo sprintf('<li class="fa-bullseye"><strong class="fwb">%1$s</strong> %2$s </li>', __('Genres', 'toroplay'), $genres->results);
                                }

                                $tags = $details->tags();

                                if ($tags->has) {
                                    echo sprintf('<li class="fa-bullseye"><strong class="fwb">%1$s</strong> %2$s </li>', __('Tags', 'toroplay'), $tags->results);
                                }

                                ?>
                            </ul>
                        </div>

                        <div class="MvTbCn anmt" id="MvTb-cast">
                            <ul class="ListCast Rows AF A06 B03 C02 D20 E02">
                                <?php

                                $casts = $details->casts_raw('w185');

                                if ($casts->has) {
                                    foreach ($casts->results as $result) {
                                        echo '<li> <a aria-label="' . $result['nme'] . '" href="' . $result['url'] . '"> <figure> <span class="Objf"> <img src="' . $result['src'] . '" alt="' . $result['nme'] . '"> </span> <figcaption> ' . $result['nme'] . ' </figcaption> </figure> </a> </li>';
                                    }
                                }

                                ?>
                            </ul>
                        </div>

                        <div class="TPostBg Objf">
                            <?php echo $details->backdrop($bds, get_the_title()); ?>
                        </div>
                    </div>

                    <?php

                    if (comments_open() || get_comments_number()) {
                        comments_template();
                    }

                    ?>
                </main>

                <?php get_sidebar(); ?>
            </div>
        </div>
    </div>
</div>