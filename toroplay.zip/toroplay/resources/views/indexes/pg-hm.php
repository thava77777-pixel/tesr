<div class="Body Container">
    <div class="Content">
        <div class="Container">

            <?php


            $letters_up = (bool) get_option('tp_home_letters_up', false);

            if ($letters_up) {
                get_template_part('resources/views/components/lttrs');
            }

            $sv1 = (bool) get_option('tp_home_swiper_sv1', false);

            if ($sv1) {
                get_template_part('resources/views/components/swpr', 'typ1', [
                    'orderby' => (string) get_option('tp_home_swiper_sv1_orderby', 'none'),
                    'number' => (int) get_option('tp_home_swiper_sv1_number', 6),
                    'order' => (string) get_option('tp_home_swiper_sv1_order', 'DESC'),
                    'type' => (string) get_option('tp_home_swiper_sv1_type', 'mvs')
                ]);
            }

            ?>

            <div class="<?php sidebar_class(); ?>">
                <main>
                    <?php

                    $sv2 = (bool) get_option('tp_home_swiper_sv2', false);
                    if ($sv2) {
                        get_template_part('resources/views/components/swpr', 'typ2', [
                            'orderby' => (string) get_option('tp_home_swiper_sv2_orderby', 'none'),
                            'number' => (int) get_option('tp_home_swiper_sv2_number', 6),
                            'order' => (string) get_option('tp_home_swiper_sv2_order', 'DESC'),
                            'type' => (string) get_option('tp_home_swiper_sv2_type', 'mvs')
                        ]);
                    }

                    $movies = (bool) get_option('tp_home_section_movies', false);
                    if ($movies) {
                        get_template_part('resources/views/components/sctns', 'mvs', [
                            'orderby' => (string) get_option('tp_home_section_movies_orderby', 'none'),
                            'number' => (int) get_option('tp_home_section_movies_number', 10),
                            'order' => (string) get_option('tp_home_section_movies_order', 'DESC'),
                            'name' => (string) get_option('tp_home_section_movies_name', ''),
                            'url' => (string) get_option('tp_home_section_movies_url', '')
                        ]);
                    }

                    $series = (bool) get_option('tp_home_section_series', false);
                    if ($series) {
                        get_template_part('resources/views/components/sctns', 'srs', [
                            'orderby' => (string) get_option('tp_home_section_series_orderby', 'none'),
                            'number' => (int) get_option('tp_home_section_series_number', 10),
                            'order' => (string) get_option('tp_home_section_series_order', 'DESC'),
                            'name' => (string) get_option('tp_home_section_series_name', ''),
                            'url' => (string) get_option('tp_home_section_series_url', '')
                        ]);
                    }

                    $seasons = (bool) get_option('tp_home_section_seasons', false);
                    if ($seasons) {
                        get_template_part('resources/views/components/sctns', 'ssns', [
                            'number' => (int) get_option('tp_home_section_seasons_number', 10),
                            'order' => (string) get_option('tp_home_section_seasons_order', 'DESC'),
                            'name' => (string) get_option('tp_home_section_seasons_name', ''),
                            'url' => (string) get_option('tp_home_section_seasons_url', '')
                        ]);
                    }

                    $episodes = (bool) get_option('tp_home_section_episodes', false);
                    if ($episodes) {
                        get_template_part('resources/views/components/sctns', 'psds', [
                            'number' => (int) get_option('tp_home_section_episodes_number', 10),
                            'order' => (string) get_option('tp_home_section_episodes_order', 'DESC'),
                            'name' => (string) get_option('tp_home_section_episodes_name', ''),
                            'url' => (string) get_option('tp_home_section_episodes_url', '')
                        ]);
                    }

                    ?>
                </main>

                <?php get_sidebar(); ?>
            </div>

            <?php

            $letters_bt = (bool) get_option('tp_home_letters_bt', false);
            if ($letters_bt) {
                get_template_part('resources/views/components/lttrs');
            }

            ?>

        </div>
    </div>
</div>