<?php

$details = new TOROPLAY\components\movies($post->ID);

$wordwrp = get_the_title();

if (!strlen($wordwrp) <= 20) {
    $format = explode('{unique.wordwrap}', wordwrap($wordwrp, 20, ' {unique.wordwrap} ', false));
    $wordwrp = isset($format[0]) ? $format[0] : '';
}

?>

<li>
    <div class="TPost B">
        <a href="<?php the_permalink(); ?>">
            <div class="Image">
                <figure class="Objf TpMvPlay fa-play">
                    <?php echo $details->thumbnail('w92', get_the_title()); ?>
                </figure>
            </div>
            <div class="Title"><?php echo $wordwrp; ?></div>
        </a>
    </div>
</li>