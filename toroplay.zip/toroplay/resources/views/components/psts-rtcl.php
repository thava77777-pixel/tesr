<article class="news">
    <?php

    if (get_the_post_thumbnail($post->ID, 'original')) {
        echo '<div class="news-bg pctr"> <figure> ' . get_the_post_thumbnail($post->ID, 'original') . ' </figure> </div>';
    }

    ?>
    <aside>
        <header>
            <h1 class="ttl"><?php the_title(); ?></h1>
            <p class="meta">
                <span class="usr-nm"><span><?php echo get_the_author_meta('display_name', $post->post_author); ?></span> <?php echo get_the_date(); ?></span>
            </p>
        </header>
        <div class="Description">
            <?php the_excerpt(); ?>
        </div>
        <a class="lnk-blk" href="<?php echo get_permalink(); ?>"><span class="sr-only"><?php the_title(); ?></span></a>
    </aside>
</article>