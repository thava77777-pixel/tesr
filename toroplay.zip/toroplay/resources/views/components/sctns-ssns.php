<section>
    <?php

    $url = $args['url'] ?? null;
    $name = $args['name'] ?? null;
    $order = $args['order'] ?? 'DESC';
    $number = $args['number'] ?? 12;

    if (!is_null($name)) {
        if (is_null($url) or empty($url)) {
            echo sprintf('<div class="Top"> <h2 class="Title"> %1$s </h2> </div>', $name);
        } else {
            echo sprintf('<div class="Top"> <h2 class="Title"> %1$s </h2> <a href="%2$s" class="Button STPb">%3$s</a> </div>', $name, $url, __('View more', 'toroplay'));
        }
    }

    ?>
    <ul class="MovieList Rows AX A06 B04 C03 E20 NoLmtxt">
        <?php

        $seasons = get_terms([
            'taxonomy'    => 'seasons',
            'orderby'     => 'term_id',
            'number'      => $number,
            'order'       => $order
        ]);

        if ($seasons) {
            foreach ($seasons as $season) {
                $id = get_term_meta($season->term_id, 'tr_id_post', true);

                get_template_part('resources/views/components/ssns', 'rtcl', [
                    'id' => $id,
                    'term_id' => $season->term_id
                ]);
            }
        }

        wp_reset_postdata();

        ?>
    </ul>
</section>