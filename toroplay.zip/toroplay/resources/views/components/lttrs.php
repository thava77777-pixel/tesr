<?php

$categories = get_categories([
    'taxonomy' => 'letters',
    'hide_empty' => false
]);

if ($categories) {
    echo '<ul class="AZList">';

    foreach ($categories as $category) {
        $current = single_term_title('', false);
        $link = esc_url(get_term_link($category));

        if ($category->name == $current) {
            echo '<li class="Current"><a aria-label="' . $category->name . '" href="' . $link . '">' . $category->name . '</a></li>';
        } else {
            echo '<li><a aria-label="' . $category->name . '"href="' . $link . '">' . $category->name . '</a></li>';
        }
    }

    echo '</ul>';
}
