<?php

$details = new TOROPLAY\components\movies($post->ID);

?>

<li>
    <div class="TPost A">
        <a href="<?php the_permalink(); ?>">
            <div class="Image">
                <figure class="Objf TpMvPlay fa-play">
                    <?php echo $details->thumbnail('w92', get_the_title()); ?>
                </figure>
            </div>
            <div class="Title"><?php the_title(); ?></div>
        </a>
        <p class="Info">
            <?php

            $ranking = $details->ranking();

            if ($ranking->has) {
                echo sprintf('<span class="Vote fa-star"> %1$s </span>', $ranking->results);
            }

            $minutes = $details->minutes();

            if ($minutes->has) {
                echo sprintf('<span class="Time fa-clock far"> %1$s </span>', $minutes->results);
            }

            $release = $details->release();

            if ($release->has) {
                echo sprintf('<span class="Date fa-calendar-alt far"> %1$s </span>', $release->results);
            }

            ?>
        </p>
    </div>
</li>