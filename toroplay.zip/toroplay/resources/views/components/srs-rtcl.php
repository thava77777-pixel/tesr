<?php

$details = new TOROPLAY\components\series($post->ID);
$pts = get_option('tp_images_pts_series', 'w185');

?>

<li class="TPostMv">
    <article class="TPost C">
        <a href="<?php the_permalink(); ?>">
            <div class="Image">
                <figure class="Objf TpMvPlay fa-play">
                    <?php

                    echo $details->thumbnail($pts, get_the_title());

                    $seasons = $details->seasons();

                    if ($seasons->has) {
                        echo sprintf('<figcaption> <span class="ClB"> %1$s </span> - %2$s </figcaption>', $seasons->results,  __('Seasons', 'toroplay'));
                    }

                    ?>
                </figure>
            </div>
            <h2 class="Title"><?php the_title(); ?></h2>
        </a>
        <div class="TPMvCn anmt">
            <div class="Title"><?php the_title(); ?></div>
            <p class="Info">
                <?php

                $ranking = $details->ranking();

                if ($ranking->has) {
                    echo sprintf('<span class="Vote fa-star"> %1$s </span>', $ranking->results);
                }

                $minutes = $details->minutes();

                if ($minutes->has) {
                    echo sprintf('<span class="Time fa-clock far"> %1$s </span>', $minutes->results);
                }

                $release = $details->release();

                if ($release->has) {
                    echo sprintf('<span class="Date fa-calendar-alt far"> %1$s </span>', $release->results);
                }

                ?>
            </p>
            <div class="Description">
                <?php

                $excerpt = $details->excerpt();

                if ($excerpt->has) {
                    echo sprintf('<p> %1$s </p>', $excerpt->results);
                }

                $director = $details->director();

                if ($director->has) {
                    echo sprintf('<p class="Director"><span>%1$s</span> %2$s </p>', __('Director', 'toroplay'), $director->results);
                }

                $genres = $details->genres();

                if ($genres->has) {
                    echo sprintf('<p class="Genre"><span>%1$s</span> %2$s </p>', __('Genres', 'toroplay'), $genres->results);
                }

                $casts = $details->casts();

                if ($casts->has) {
                    echo sprintf('<p class="Actors"><span>%1$s</span> %2$s </p>', __('Casts', 'toroplay'), $casts->results);
                }

                ?>
            </div>
        </div>
    </article>
</li>