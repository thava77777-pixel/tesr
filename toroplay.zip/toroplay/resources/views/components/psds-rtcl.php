<?php

$details = new TOROPLAY\components\episodes($args['term_id'], $args['id']);
$pts = get_option('tp_images_pts_episodes', 'w185');

?>
<li class="TPostMv">
    <article class="TPost C">
        <a href="<?php echo esc_url(get_term_link($args['term_id'])); ?>">
            <div class="Image">
                <figure class="Objf TpMvPlay fa-play">
                    <?php

                    echo $details->thumbnail($pts, get_the_title($args['id']));

                    $name = $details->name();

                    $season_number = $details->season_number();
                    $episode_number = $details->episode_number();

                    if ($name->has and $season_number->has and $episode_number->has) {
                        if (!strlen($name->results) <= 20) {
                            $format = explode('{unique.wordwrap}', wordwrap($name->results, 20, ' {unique.wordwrap} ', false));
                            $name->results = isset($format[0]) ? $format[0] : '';
                        }

                        if ($season_number->results != 00) {
                            echo sprintf('<figcaption> <span class="ClB"> %1$sx%2$s </span> - %3$s</figcaption>', $season_number->results, $episode_number->results, $name->results);
                        } else {
                            echo sprintf('<figcaption> <span class="ClB"> %1$s </span> - %2$s</figcaption>', $episode_number->results, $name->results);
                        }
                    }

                    ?>
                </figure>
            </div>
            <h2 class="Title"><?php echo get_the_title($args['id']); ?></h2>
            <?php

            $date = $details->date();

            if ($date->has) {
                echo sprintf('<span class="Year"> %1$s </span>', $date->results);
            }

            ?>
        </a>
    </article>
</li>