<?php

$type = $args['type'] ?? null;
$order = $args['order'] ?? 'DESC';
$number = $args['number'] ?? 12;
$orderby = $args['orderby'] ?? 'none';

switch ($type) {
    case 'mvs':
        $type = 'movies';
        break;
    case 'srs':
        $type = 'series';
        break;
    default:
        $type = 'movies';
        break;
}

?>

<div class="MovieListTopCn">
    <div class="MovieListTop" x-data="{swiper: null}" x-init="swiper = new Swiper($refs.container, { loop: false, spaceBetween: 0, slidesPerView: 2, breakpoints: { 450: { slidesPerView: 4,},768: {slidesPerView: 6,},1000: {slidesPerView: 8,},},autoplay: {delay: 3500,disableOnInteraction: false,},})">
        <div class="swiper-container" x-ref="container">
            <div class="swiper-wrapper">
                <?php

                query_posts([
                    'post_type'           => array($type),
                    'posts_per_page'      => $number,
                    'order'               => $order,
                    'orderby'             => $orderby,
                    'post_status'         => 'publish',
                    'no_found_rows'       => true,
                    'ignore_sticky_posts' => true,
                ]);

                if (have_posts()) :
                    while (have_posts()) : the_post();
                        switch ($post->post_type) {
                            case 'movies':
                                get_template_part('resources/views/components/swpr', 'mvs1');
                                break;
                            case 'series':
                                get_template_part('resources/views/components/swpr', 'srs1');
                                break;
                        }
                    endwhile;
                endif;

                wp_reset_postdata();

                ?>
            </div>
        </div>
    </div>
</div>