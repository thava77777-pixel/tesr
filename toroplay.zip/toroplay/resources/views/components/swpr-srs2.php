<?php

$details = new TOROPLAY\components\series($post->ID);
$bds = get_option('tp_images_bds_series', 'w300');

?>

<div class="swiper-slide">
    <div class="TPostMv">
        <div class="TPost D">
            <a href="<?php the_permalink(); ?>">
                <div class="Image">
                    <figure class="Objf">
                        <?php echo $details->backdrop($bds, get_the_title()); ?>
                    </figure>
                </div>
            </a>
            <div class="TPMvCn">
                <a href="<?php the_permalink(); ?>">
                    <div class="Title"><?php the_title(); ?></div>
                </a>
                <p class="Info">
                    <?php

                    $ranking = $details->ranking();

                    if ($ranking->has) {
                        echo sprintf('<span class="Vote fa-star"> %1$s </span>', $ranking->results);
                    }

                    $minutes = $details->minutes();

                    if ($minutes->has) {
                        echo sprintf('<span class="Time fa-clock far"> %1$s </span>', $minutes->results);
                    }

                    $release = $details->release();

                    if ($release->has) {
                        echo sprintf('<span class="Date fa-calendar-alt far"> %1$s </span>', $release->results);
                    }

                    ?>
                </p>
                <div class="Description">
                    <?php

                    $excerpt = $details->excerpt();

                    if ($excerpt->has) {
                        echo sprintf('<p> %1$s </p>', $excerpt->results);
                    }

                    $director = $details->director();

                    if ($director->has) {
                        echo sprintf('<p class="Director"><span>%1$s</span> %2$s </p>', __('Director', 'toroplay'), $director->results);
                    }

                    $genres = $details->genres();

                    if ($genres->has) {
                        echo sprintf('<p class="Genre"><span>%1$s</span> %2$s </p>', __('Genres', 'toroplay'), $genres->results);
                    }

                    ?>
                </div>
                <div class="Cast">
                    <?php

                    $casts = $details->casts_raw('w45');

                    if ($casts->has) {
                        foreach ($casts->results as $k => $result) {
                            if ($k < 4) {
                                echo '<a aria-label="' . $result['nme'] . '" href="' . $result['url'] . '"> <img src="' . $result['src'] . '" alt="' . $result['nme'] . '" /> </a>';
                            }
                        }
                    }

                    ?>

                    <a aria-label="<?php the_title(); ?>" href="<?php the_permalink(); ?>" class="Button STPa fa-ellipsis-h far"></a>
                </div>
                <p class="tpmvft">
                    <a aria-label="<?php the_title(); ?>" href="<?php the_permalink(); ?>" class="Button TPlay fa-play">
                        <?php

                        echo sprintf('%1$s <strong>%2$s</strong>', __('Watch', 'toroplay'), __('Series', 'toroplay'));

                        ?>
                    </a>
                </p>
            </div>
        </div>
    </div>
</div>