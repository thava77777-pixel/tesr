<section>
    <?php

    $url = $args['url'] ?? null;
    $name = $args['name'] ?? null;
    $order = $args['order'] ?? 'DESC';
    $number = $args['number'] ?? 12;
    $orderby = $args['orderby'] ?? 'none';

    if (!is_null($name)) {
        if (is_null($url) or empty($url)) {
            echo sprintf('<div class="Top"> <h2 class="Title"> %1$s </h2> </div>', $name);
        } else {
            echo sprintf('<div class="Top"> <h2 class="Title"> %1$s </h2> <a href="%2$s" class="Button STPb">%3$s</a> </div>', $name, $url, __('View more', 'toroplay'));
        }
    }

    ?>
    <ul class="MovieList Rows AX A06 B04 C03 E20 NoLmtxt">
        <?php
        query_posts([
            'post_type'           => array('movies'),
            'posts_per_page'      => $number,
            'order'               => $order,
            'orderby'             => $orderby,
            'post_status'         => 'publish',
            'no_found_rows'       => true,
            'ignore_sticky_posts' => true,
        ]);

        if (have_posts()) :
            while (have_posts()) : the_post();
                get_template_part('resources/views/components/mvs', 'rtcl');
            endwhile;
        endif;

        wp_reset_postdata();

        ?>
    </ul>
</section>