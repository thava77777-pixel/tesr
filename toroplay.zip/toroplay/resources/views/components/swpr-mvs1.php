<?php

$details = new TOROPLAY\components\movies($post->ID);
$pts = get_option('tp_images_pts_movies', 'w185');

?>

<div class="swiper-slide">
    <div class="TPostMv">
        <div class="TPost B">
            <a href="<?php the_permalink(); ?>">
                <div class="Image">
                    <figure class="Objf TpMvPlay fa-play">
                        <?php echo $details->thumbnail($pts, get_the_title()); ?>
                    </figure>
                </div>
                <div class="Title"><?php the_title(); ?></div>
            </a>
        </div>
    </div>
</div>