<?php

$details = new TOROPLAY\components\seasons($args['term_id'], $args['id']);
$pts = get_option('tp_images_pts_seasons', 'w185');

?>

<li class="TPostMv">
    <article class="TPost C">
        <a href="<?php echo esc_url(get_term_link($args['term_id'])); ?>">
            <div class="Image">
                <figure class="Objf TpMvPlay fa-play">
                    <?php

                    echo $details->thumbnail($pts, get_the_title($args['id']));

                    $number_of_episodes = $details->number_of_episodes();

                    if ($number_of_episodes->has) {
                        if ($number_of_episodes->results != 00) {
                            echo sprintf('<figcaption> <span class="ClB"> %1$s </span> - %2$s</figcaption>', $number_of_episodes->results, __('Episodes', 'toroplay'));
                        }
                    }

                    ?>
                </figure>
            </div>
            <h2 class="Title"><?php echo get_the_title($args['id']); ?></h2>

            <?php

            $name = $details->name();
            $release = $details->release();

            if ($name->has and $release->has) {
                echo sprintf('<span class="Year"> %1$s - %2$s</h2>', $name->results, $release->results);
            }

            ?>
        </a>
    </article>
</li>