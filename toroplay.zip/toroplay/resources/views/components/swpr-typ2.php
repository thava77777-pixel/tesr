<?php

$type = $args['type'] ?? null;
$order = $args['order'] ?? 'DESC';
$number = $args['number'] ?? 12;
$orderby = $args['orderby'] ?? 'none';

switch ($type) {
    case 'mvs':
        $type = 'movies';
        break;
    case 'srs':
        $type = 'series';
        break;
    default:
        $type = 'movies';
        break;
}

?>

<div class="MovieListSldCn">
    <div class="MovieListSld" x-data="{swiper: null}" x-init="swiper = new Swiper($refs.container, {loop: true,spaceBetween: 16,autoHeight: false,slidesPerView: 1,autoplay: {delay: 3500,disableOnInteraction: false,},})">
        <div class="swiper-container" x-ref="container">
            <div class="swiper-wrapper">
                <?php

                query_posts([
                    'post_type'           => array($type),
                    'posts_per_page'      => $number,
                    'order'               => $order,
                    'orderby'             => $orderby,
                    'post_status'         => 'publish',
                    'no_found_rows'       => true,
                    'ignore_sticky_posts' => true,
                ]);

                if (have_posts()) :
                    while (have_posts()) : the_post();
                        switch ($post->post_type) {
                            case 'movies':
                                get_template_part('resources/views/components/swpr', 'mvs2');
                                break;
                            case 'series':
                                get_template_part('resources/views/components/swpr', 'srs2');
                                break;
                        }
                    endwhile;
                endif;

                wp_reset_postdata();

                ?>
            </div>
        </div>
    </div>
</div>