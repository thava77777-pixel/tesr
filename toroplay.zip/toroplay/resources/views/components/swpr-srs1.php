<?php

$details = new TOROPLAY\components\series($post->ID);
$pts = get_option('tp_images_pts_series', 'w185');

?>

<div class="swiper-slide">
    <div class="TPostMv">
        <div class="TPost B">
            <a href="<?php the_permalink(); ?>">
                <div class="Image">
                    <figure class="Objf TpMvPlay fa-play">
                        <?php echo $details->thumbnail($pts, get_the_title()); ?>
                    </figure>
                    <span class="TpTv BgA">TV</span>
                </div>
                <div class="Title"><?php the_title(); ?></div>
            </a>
        </div>
    </div>
</div>