<?php

get_header();

if (is_archive()) {
    $object = $wp_query->get_queried_object();

    get_template_part('resources/views/indexes/pg', 'mvs', [
        'name' => '',
        'queries' => array()
    ]);
}

get_footer();
