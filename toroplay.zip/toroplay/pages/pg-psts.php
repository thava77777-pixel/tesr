<?php

/**
 * Template Name: Posts
 */

get_header();


if (is_page()) {

    $object = $wp_query->get_queried_object();

    get_template_part('resources/views/indexes/pg', 'psts', [
        'name' => $object->post_title,
        'queries' => array()
    ]);
}

get_footer();
