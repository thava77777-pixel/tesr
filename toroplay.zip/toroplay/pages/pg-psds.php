<?php

/**
 * Template Name: Episodes
 */

get_header();


if (is_page()) {

    $object = $wp_query->get_queried_object();

    get_template_part('resources/views/indexes/pg', 'psds', [
        'name' => $object->post_title,
        'queries' => array()
    ]);
}

get_footer();
