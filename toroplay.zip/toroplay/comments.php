<div class="Wdgt">
    <div class="Title">
        <?php printf(__('Comments %s%s%s', 'toroplay'), '<span>', number_format_i18n(get_comments_number($post->ID)), '</span>'); ?>
    </div>

    <?php

    wp_enqueue_script('comment-reply');

    comment_form([
        'comment_notes_before'  => '',
        'comment_notes_after'   => '',
        'title_reply'           => '',
        'title_reply_before'    => '',
        'title_reply_after'     => ''
    ]);

    $comments = get_comments([
        'post_id' => $post->ID,
        'status' => 'approve',
        'number' => 12,
        'order' => 'DESC'
    ]);

    if (have_comments()) {
        echo '<ul class="CommentsList">';

        wp_list_comments([
            'style'       => 'li',
            'format'      => 'html5',
            'short_ping'  => true,
            'avatar_size' => 32,
        ], $comments);

        echo '</ul>';
    }

    ?>


</div>