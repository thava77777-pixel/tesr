<?php

get_header();

if (is_404()) {
?>
    <div class="Body Container">
        <div class="Content">
            <div class="Container">

                <div class="e404">
                    <i class="fa-sad-tear fal"></i>
                    <div class="ttlbg">404</div>
                    <div class="ttl"><?php echo __('Page Not Found', 'toroplay'); ?></div>
                    <p><?php echo __('The page you looking for is not found', 'toroplay'); ?></p>
                    <p>
                        <a href="<?php echo get_home_url(); ?>" class="Button"><?php echo __('Back to Home', 'toroplay'); ?></a>
                    </p>
                </div>

            </div>
        </div>
    </div>
<?php
}

get_footer();

?>