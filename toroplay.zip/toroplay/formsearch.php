<form action="<?php echo get_home_url(); ?>" autocomplete="off">
    <label class="Form-Icon">
        <input aria-label="<?php echo __('Search', 'toroplay'); ?>" type="text" id="s" name="s" placeholder="<?php echo __('Search', 'toroplay'); ?>">
        <i class="fa-search"></i>
    </label>

    <div class="Result anmt">
        <ul class="MovieList"></ul>
    </div>
</form>