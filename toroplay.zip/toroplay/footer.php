<footer class="Footer">
    <div class="Top Container">
        <div class="MnBrCn BgA">
            <div class="MnBr EcBgA">
                <div class="Container">
                    <?php

                    if (is_front_page() or is_home()) {
                        if (get_custom_logo()) {
                            echo '<figure class="Logo"> <a href="#!"> ' . the_custom_logo() . ' </a> </figure>';
                        } else {
                            echo '<figure class="Logo"> <a href="#!"> <img width="170" height="25" src="' . TOROPLAY_DIR_URI . 'resources/assets/img/toroplay-logo.png" alt="toroplay"> </a> </figure>';
                        }
                    } else {
                        if (get_custom_logo()) {
                            echo '<figure class="Logo"> <a href="' . get_home_url() . '"> ' . the_custom_logo() . ' </a> </figure>';
                        } else {
                            echo '<figure class="Logo"> <a href="' . get_home_url() . '"> <img width="170" height="25" src="' . TOROPLAY_DIR_URI . 'resources/assets/img/toroplay-logo.png" alt="toroplay"> </a> </figure>';
                        }
                    }

                    ?>

                    <div class="Rght">
                        <?php

                        if (has_nav_menu('footer')) {
                            wp_nav_menu(
                                array(
                                    'menu'               =>  'Menu',
                                    'theme_location'     =>  'footer',
                                    'items_wrap'         =>  '<nav class="Menu"><ul>%3$s</ul></nav>',
                                    'container'          =>  false
                                )
                            );
                        }

                        ?>
                        <ul class="ListSocial">
                            <?php

                            $instagram = (string) get_option('tp_footer_instagram', false);
                            $facebook = (string) get_option('tp_footer_facebook', false);
                            $twitter = (string) get_option('tp_footer_twitter', false);
                            $tumblr = (string) get_option('tp_footer_tumblr', false);
                            $reddit = (string) get_option('tp_footer_reddit', false);

                            if (!empty($instagram)) {
                                echo '<li> <a aria-label="instagram" href="' . $instagram . '" class="fa-instagram fab"></a> </li>';
                            }

                            if (!empty($facebook)) {
                                echo '<li> <a aria-label="facebook" href="' . $facebook . '" class="fa-facebook fab"></a> </li>';
                            }

                            if (!empty($twitter)) {
                                echo '<li> <a aria-label="twitter" href="' . $twitter . '" class="fa-twitter fab"></a> </li>';
                            }

                            if (!empty($tumblr)) {
                                echo '<li> <a aria-label="tumblr" href="' . $tumblr . '" class="fa-tumblr fab"></a> </li>';
                            }

                            if (!empty($reddit)) {
                                echo '<li> <a aria-label="reddit" href="' . $reddit . '" class="fa-reddit fab"></a> </li>';
                            }

                            ?>
                            <li>
                                <a aria-label="Up" href="#Tp-Wp" class="Up fa-arrow-up far"></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="Bot Container">
        <?php

        $text = (string) get_option('tp_footer_text', false);

        if (!empty($text)) {
            echo '<div class="WebDescription"> ' . $text . ' </div>';
        }

        ?>
    </div>
</footer>

</div>

<?php

wp_footer();

?>

</body>

</html>