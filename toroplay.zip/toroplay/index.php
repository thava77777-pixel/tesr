<?php

get_header();

if (is_front_page()) {
    get_template_part('resources/views/indexes/pg', 'hm');
}

get_footer();
