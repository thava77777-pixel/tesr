<?php

get_header();

if (is_tax()) {
    $object = $wp_query->get_queried_object();

    get_template_part('resources/views/indexes/sngl', 'psds');
}

get_footer();
