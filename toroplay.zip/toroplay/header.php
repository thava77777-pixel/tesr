<?php

$class = array();

$border = (bool) get_option('tp_layout_border', false);
if ($border) {
    $class[] = 'NoBrdRa';
}

$boxed = (bool) get_option('tp_layout_boxed', false);
if (!$boxed) {
    $class[] = 'NoBoxed';
}

$fullw = (bool) get_option('tp_layout_fullw', false);
if ($fullw) {
    $class[] = 'FullW';
}

$class = implode(' ', $class);

?>

<!doctype html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">

    <?php wp_head(); ?>

    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet preload prefetch" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;700&display=swap" type="text/css" as="style">
</head>

<body <?php body_class($class); ?> x-data="{ menu: false, uDpd: false }" @keydown.escape="menu = false">

    <div class="Tp-Wp" id="Tp-Wp" :class="{ 'show': menu }">

        <header class="Header MnBrCn BgA">
            <div class="MnBr EcBgA">
                <div class="Container">
                    <?php

                    if (is_front_page() or is_home()) {
                        if (get_custom_logo()) {
                            echo '<figure class="Logo"> <a href="#!"> ' . the_custom_logo() . ' </a> </figure>';
                        } else {
                            echo '<figure class="Logo"> <a href="#!"> <img width="170" height="25" src="' . TOROPLAY_DIR_URI . 'resources/assets/img/toroplay-logo.png" alt="toroplay"> </a> </figure>';
                        }
                    } else {
                        if (get_custom_logo()) {
                            echo '<figure class="Logo"> <a href="' . get_home_url() . '"> ' . the_custom_logo() . ' </a> </figure>';
                        } else {
                            echo '<figure class="Logo"> <a href="' . get_home_url() . '"> <img width="170" height="25" src="' . TOROPLAY_DIR_URI . 'resources/assets/img/toroplay-logo.png" alt="toroplay"> </a> </figure>';
                        }
                    }

                    ?>

                    <button aria-label="menu" type="button" @click="menu = !menu" class="Button MenuBtn AAShwHdd-lnk CXHd" @click="menu = !menu">
                        <i></i><i></i><i></i>
                    </button>

                    <span class="MenuBtnClose AAShwHdd-lnk CXHd" @click="menu = !menu"></span>
                    <div class="Rght BgA">
                        <div class="Search">
                            <?php get_template_part('formsearch'); ?>
                        </div>

                        <?php

                        if (has_nav_menu('header')) {
                            wp_nav_menu(
                                array(
                                    'menu'               =>  'Menu',
                                    'theme_location'     =>  'header',
                                    'items_wrap'         =>  '<nav class="Menu"><ul>%3$s</ul></nav>',
                                    'container'          =>   false
                                )
                            );
                        }

                        ?>
                    </div>

                </div>
            </div>
        </header>