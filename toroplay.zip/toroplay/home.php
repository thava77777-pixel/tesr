<?php

get_header();

if (is_home()) {
    get_template_part('resources/views/indexes/pg', 'hm');
}

get_footer();
