<?php

/**
 * toroplay functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package toroplay
 */

$_details = wp_get_theme('toroplay');
$dir_path = (substr(get_template_directory(),     -1) === '/') ? get_template_directory()     : get_template_directory()     . '/';
$dir_uri  = (substr(get_template_directory_uri(), -1) === '/') ? get_template_directory_uri() : get_template_directory_uri() . '/';

/** TP */
define('TP_VERSION', $_details['Version']);

define('TOROPLAY_DIR_PATH', $dir_path);
define('TOROPLAY_DIR_URI',  $dir_uri);

/** TR */
define('TR_GRABBER_MOVIES', true);
define('TR_GRABBER_SERIES', true);

/** created */
function tt_toroplay_init()
{
    load_theme_textdomain('toroplay', TOROPLAY_DIR_PATH . 'languages');
}
add_action('init', 'tt_toroplay_init');

/** mounted */

use TOROPLAY\app;

function tt_toroplay_app()
{
    if (!class_exists('app')) {
        require TOROPLAY_DIR_PATH . 'app/presets/class-preset-app.php';
    }

    $themes = new app;

    $themes->created();
    $themes->mounted();
}
tt_toroplay_app();

function excerpt()
{
    return 25;
}
add_filter('excerpt_length', 'excerpt');

function excerpt_more()
{
    return '...';
}
add_filter('excerpt_more', 'excerpt_more');

function tm_removes()
{
    if ($GLOBALS['pagenow'] !== 'wp-login.php' and !is_admin() and !is_customize_preview()) {
        if (!is_user_logged_in()) {
            remove_action('wp_head', 'print_emoji_detection_script', 7);
            remove_action('wp_print_styles', 'print_emoji_styles');
            remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
            remove_filter('the_content_feed', 'wp_staticize_emoji');
            remove_filter('comment_text_rss', 'wp_staticize_emoji');

            wp_deregister_script('jquery');
            wp_deregister_script('wp-embed');

            wp_register_script('jquery', false);
        }
    }
}
add_action('init', 'tm_removes');

function tp_pre_get_posts($query)
{
    if (!$query->is_main_query() || $query->is_admin())
        return false;

    if ($query->is_category() and !is_admin()) {
        $query->set('post_type', ['movies', 'series']);
        $query->set('posts_per_page', (int) get_option('tp_pages_pg_category', 24));
    }

    if ($query->is_search() and !is_admin()) {
        $query->set('post_type', ['movies', 'series']);
        $query->set('posts_per_page', (int) get_option('tp_pages_pg_search', 24));
    }

    if ($query->is_tag() and !is_admin()) {
        $query->set('post_type', ['movies', 'series']);
        $query->set('posts_per_page', (int) get_option('tp_pages_pg_taxonomy', 24));
    }

    if ($query->is_tax() and !is_admin()) {
        $query->set('post_type', ['movies', 'series']);
        $query->set('posts_per_page', (int) get_option('tp_pages_pg_taxonomy', 24));
    }

    if ($query->is_home() && $query->is_main_query()) {
        $query->set('query_vars', '');
    }

    return $query;
}
add_action('pre_get_posts', 'tp_pre_get_posts');

function tp_posts_request($request, \WP_Query $q)
{
    if ($q->is_home() && $q->is_main_query()) {
        $q->set('fields', 'ids');
        $request = '';
    }

    return $request;
}

add_filter('posts_request', 'tp_posts_request', 100, 2);


function remove_class($wp_classes, $extra_classes)
{
    $class_delete = array('tag', 'archive', 'category', 'tax-episodes', 'tax-seasons');

    foreach ($wp_classes as $class_css_key => $class_css) {
        if (in_array($class_css, $class_delete)) {
            unset($wp_classes[$class_css_key]);
        }
    }

    return array_merge($wp_classes, (array) $extra_classes);
}
add_filter('body_class', 'remove_class', 10, 2);

add_action('after_switch_theme', 'flush_rewrite_rules');


if (!function_exists('tr_check_type')) {
    function tr_check_type($id, $display = NULL)
    {
        $return = '';
        $type = get_post_meta($id, 'tr_post_type', true);

        if ($type == 2) {
            $return = 2;
        } else {
            $return = 1;
        }

        if ($display == NULL) {
            return $return;
        } else {
            echo $return;
        }
    }
}

if (!function_exists('sidebar_class')) {
    function sidebar_class()
    {
        $class = array('TpRwCont');
        $sidebar = (string) get_option('tp_layout_sidebar', 'NoSdbr');

        if ($sidebar !== 'NoSdbr') {
            $class[] = $sidebar;
        }

        echo implode(' ', $class);
    }
}
