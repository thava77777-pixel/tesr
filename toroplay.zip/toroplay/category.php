<?php

get_header();

if (is_category()) {
    $object = $wp_query->get_queried_object();

?>

    <div class="Body Container">
        <div class="Content">
            <div class="Container">
                <div class="TpRwCont">
                    <main>

                        <section>
                            <div class="Top">
                                <h1><?php echo $object->name; ?></h1>
                            </div>
                            <?php

                            if (category_description()) {
                                echo sprintf('<div class="description"> %1$s </div>', category_description());
                            }

                            ?>

                            <ul class="MovieList Rows AF A06 B04 C03 E20">
                                <?php

                                if (have_posts()) :
                                    while (have_posts()) : the_post();

                                        switch ($post->post_type) {
                                            case 'movies':
                                                get_template_part('resources/views/components/mvs', 'rtcl');
                                                break;
                                            case 'series':
                                                get_template_part('resources/views/components/srs', 'rtcl');
                                                break;
                                        }

                                    endwhile;
                                endif;

                                ?>
                            </ul>
                        </section>

                        <?php

                        the_posts_pagination([
                            'screen_reader_text' => ' ',
                            'before_page_number' => '',
                            'prev_text' => '<i class="fa-chevron-left"></i>',
                            'next_text' => '<i class="fa-chevron-right"></i>',
                            'mid_size'  => 2,
                        ]);

                        ?>
                    </main>

                    <?php get_sidebar(); ?>
                </div>
            </div>
        </div>
    </div>

<?php
}

get_footer();
