<?php 

// We are waves of the same sea, leaves of the same tree, flowers of the same garden
