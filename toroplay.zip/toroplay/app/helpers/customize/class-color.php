<?php
if (!class_exists('tp_color_scheme')) {

    class tp_color_scheme
    {
        public function __construct()
        {
            add_action('customize_register', array($this, 'customizer_register'));
            add_action('customize_controls_enqueue_scripts', array($this, 'customize_js'));
            add_action('customize_controls_print_footer_scripts', array($this, 'color_scheme_template'));
            add_action('customize_preview_init', array($this, 'customize_preview_js'));
            add_action('wp_head', array($this, 'output_css'), 200);
        }
        public $options = array(
            'tp_color_1',
            'tp_color_2',
            'tp_color_3',
            'tp_color_4',
            'tp_color_5',
            'tp_color_6',
            'tp_color_7',
            'tp_color_8',
        );
        public function get_color_schemes()
        {
            return array(
                'default' => array(
                    'label'  => __('Default', 'toroplay'),
                    'colors' => array(
                        '#eceff1',
                        '#ffffff',
                        '#000000',
                        '#78909c',
                        '#9c27b0',
                        '#ffc107',
                        '#ff5722',
                        '#000000'
                    )
                )
            );
        }
        public function customizer_register(WP_Customize_Manager $wp_customize)
        {
            $wp_customize->add_section('tr_colors', array(
                'title' => __('Colors', 'toroplay'),
            ));

            $color_schemes = $this->get_color_schemes();

            $options = array();
            foreach ($color_schemes as $color_scheme => $value) {
                $options[$color_scheme] = $value['label'];
            }


            $wp_customize->add_setting('color_scheme', array(
                'default' => 'default',
                'sanitize_callback' => 'sanitize_text_field',
                'transport'         => 'postMessage',
                'capability'     => 'edit_theme_options',
            ));

            $wp_customize->add_control('color_scheme', array(
                'label'    => __('Color scheme', 'toroplay'),
                'section'  => 'tr_colors',
                'type'    => 'select',
                'choices' => $options,
            ));

            $options = array(
                'tp_color_1' => __('Body Background color', 'toroplay'),
                'tp_color_2' => __('Content Background color', 'toroplay'),
                'tp_color_3' => __('Link color', 'toroplay'),
                'tp_color_4' => __('Text color', 'toroplay'),
                'tp_color_5' => __('Primary color', 'toroplay'),
                'tp_color_6' => __('Secondary color', 'toroplay'),
                'tp_color_7' => __('Tertiary color', 'toroplay'),
                'tp_color_8' => __('Title color', 'toroplay'),
            );

            $i = 0;

            foreach ($options as $key => $label) {
                $i++;
                $subtract = $i - 1;
                $wp_customize->add_setting($key, array(
                    'sanitize_callback' => 'sanitize_hex_color',
                    'transport' => 'postMessage',
                    'default' => $color_schemes['default']['colors'][$subtract],
                    'capability'     => 'edit_theme_options',
                ));
                $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, $key, array(
                    'label' => $label,
                    'section' => 'tr_colors',
                )));
            }
        }

        public $is_custom = false;

        public function get_color_scheme()
        {
            $color_schemes = $this->get_color_schemes();
            $color_scheme  = get_theme_mod('trcolor_scheme');
            $color_scheme  = isset($color_schemes[$color_scheme]) ? $color_scheme : 'default';
            if ('default' != $color_scheme) {
                $this->is_custom = true;
            }
            $colors = array_map('strtolower', $color_schemes[$color_scheme]['colors']);
            foreach ($this->options as $k => $option) {
                $color = get_theme_mod($option);
                if ($color && strtolower($color) != $colors[$k]) {
                    $colors[$k] = $color;
                    $this->is_custom = true;
                }
            }
            return $colors;
        }

        public function output_css()
        {
            $colors = $this->get_color_scheme();
            echo '<style id="tp_style_css" type="text/css"> ' . $this->get_css($colors) . ' </style> ';
        }

        public function get_css($colors)
        {
            $css = ':root{
                --body: %1$s;
                --cont: %2$s;
                --link: %3$s;
                --clrd: %4$s;
                --clra: %5$s;
                --clrb: %6$s;
                --clrc: %7$s;
                --title: %8$s;
            }';

            return str_replace('|', '%', vsprintf($css, $colors));
        }

        public function color_scheme_template()
        {
            $colors = array(
                'tp_color_1' => '{{ data.tp_color_1 }}',
                'tp_color_2' => '{{ data.tp_color_2 }}',
                'tp_color_3' => '{{ data.tp_color_3 }}',
                'tp_color_4' => '{{ data.tp_color_4 }}',
                'tp_color_5' => '{{ data.tp_color_5 }}',
                'tp_color_6' => '{{ data.tp_color_6 }}',
                'tp_color_7' => '{{ data.tp_color_7 }}',
                'tp_color_8' => '{{ data.tp_color_8 }}'
            );
?>
            <script type="text/html" id="tmpl-tp-color-scheme">
                <?php echo $this->get_css($colors); ?>
            </script>
<?php
        }
        public function customize_js()
        {
            wp_enqueue_script('tp-color-scheme', get_stylesheet_directory_uri() . '/resources/assets/js/color-scheme.js', array('customize-controls', 'iris', 'underscore', 'wp-util'), '1.0', true);
            wp_localize_script('tp-color-scheme', 'tpColorScheme', $this->get_color_schemes());
        }

        public function customize_preview_js()
        {
            $myvars = array(
                'ajaxurl' => admin_url('admin-ajax.php'),
            );
            wp_enqueue_script('tp-color-scheme-preview', get_stylesheet_directory_uri() . '/resources/assets/js/color-scheme-preview.js', array('customize-preview'), '1.0', true);
            wp_localize_script('tp-color-scheme-preview', 'trColor', $myvars);
        }
    }
}

new tp_color_scheme();
