<?php

namespace TOROPLAY\components;


class helpers
{

    static function image_bsl(): string
    {
        return 'http://image.tmdb.org/t/p/';
    }



    static function image_bss(): string
    {
        return 'https://image.tmdb.org/t/p/';
    }



    static function image_bds(): array
    {
        return array(

            'w300',

            'w780',

            'w1280',

            'original'

        );
    }



    static function image_lgs(): array
    {
        return array(

            'w45',

            'w92',

            'w154',

            'w185',

            'w300',

            'w500',

            'original'

        );
    }



    static function image_pts(): array
    {
        return array(

            'w92',

            'w154',

            'w185',

            'w342',

            'w500',

            'w780',

            'original'

        );
    }



    static function image_pfs(): array

    {

        return array(

            'w45',

            'w185',

            'h632',

            'original'

        );
    }



    static function image_sls(): array

    {

        return array(

            'w92',

            'w185',

            'w300',

            'original'

        );
    }

    static function heads_key(): array
    {

        return array(

            'adult',

            'air_date',

            'also_known_as',

            'alternative_titles',

            'biography',

            'birthday',

            'budget',

            'cast',

            'certifications',

            'character_names',

            'created_by',

            'crew',

            'deathday',

            'episode',

            'episode_number',

            'episode_run_time',

            'freebase_id',

            'freebase_mid',

            'general',

            'genres',

            'guest_stars',

            'homepage',

            'images',

            'imdb_id',

            'languages',

            'name',

            'network',

            'origin_country',

            'original_name',

            'original_title',

            'overview',

            'parts',

            'place_of_birth',

            'plot_keywords',

            'production_code',

            'production_companies',

            'production_countries',

            'releases',

            'revenue',

            'runtime',

            'season',

            'season_number',

            'season_regular',

            'spoken_languages',

            'status',

            'tagline',

            'title',

            'translations',

            'tvdb_id',

            'tvrage_id',

            'type',

            'video',

            'videos'

        );
    }

    static function qualities(): object
    {
        return (object) [
            1 => '2160p',
            2 => '1440p',
            3 => '1080p',
            4 => '720p',
            5 => '480p',
            6 => '360p'
        ];
    }

    static function types(): object
    {
        return (object) [
            1 => 'Download',
            2 => 'Watch online',
            3 => 'Torrent',
            4 => 'Rent or Buy'
        ];
    }

    static function languages(): object
    {

        return (object) [

            'xx' => 'No Language',



            'bi' => 'Bislama',

            'cs' => 'Český',

            'ba' => 'Bashkir',

            'ae' => 'Avestan',

            'av' => 'Avaric',

            'de' => 'Deutsch',

            'mt' => 'Malti',

            'om' => 'Oromo',

            'rm' => 'Raeto-Romance',

            'so' => 'Somali',

            'ts' => 'Tsonga',

            'vi' => 'Tiếng Việt',

            'gn' => 'Guarani',

            'ig' => 'Igbo',

            'it' => 'Italiano',

            'ki' => 'Kikuyu',

            'ku' => 'Kurdish',

            'la' => 'Latin',

            'ln' => 'Lingala',

            'lb' => 'Letzeburgesch',

            'ny' => 'Chichewa; Nyanja',

            'pl' => 'Polski',

            'si' => 'සිංහල',

            'to' => 'Tonga',

            'az' => 'Azərbaycan',

            'ce' => 'Chechen',

            'cu' => 'Slavic',

            'da' => 'Dansk',

            'hz' => 'Herero',

            'ie' => 'Interlingue',

            'rw' => 'Kinyarwanda',

            'mi' => 'Maori',

            'no' => 'Norsk',

            'pi' => 'Pali',

            'sk' => 'Slovenčina',

            'se' => 'Northern Sami',

            'sm' => 'Samoan',

            'uk' => 'Український',

            'en' => 'English',

            'ay' => 'Aymara',

            'ca' => 'Català',

            'eo' => 'Esperanto',

            'ha' => 'Hausa',

            'ho' => 'Hiri Motu',

            'hu' => 'Magyar',

            'io' => 'Ido',

            'ii' => 'Yi',

            'kn' => '?????',

            'kv' => 'Komi',

            'li' => 'Limburgish',

            'oj' => 'Ojibwa',

            'ru' => 'Pусский',

            'sr' => 'Srpski',

            'sv' => 'svenska',

            'ty' => 'Tahitian',

            'zu' => 'isiZulu',

            'ka' => 'ქართული',

            'ch' => 'Finu Chamorro',

            'be' => 'беларуская мова',

            'br' => 'Breton',

            'kw' => 'Cornish',

            'fi' => 'suomi',

            'sh' => 'Serbo-Croatian',

            'nn' => 'Norwegian Nynorsk',

            'tt' => 'Tatar',

            'tg' => 'Tajik',

            'vo' => 'Volapük',

            'ps' => 'پښتو',

            'mk' => 'Macedonian',

            'fr' => 'Français',

            'bm' => 'Bamanankan',

            'eu' => 'euskera',

            'fj' => 'Fijian',

            'id' => 'Bahasa indonesia',

            'mg' => 'Malagasy',

            'na' => 'Nauru',

            'qu' => 'Quechua',

            'sq' => 'shqip',

            'ti' => 'Tigrinya',

            'tw' => 'Twi',

            'wa' => 'Walloon',

            'ab' => 'Abkhazian',

            'bs' => 'Bosanski',

            'af' => 'Afrikaans',

            'an' => 'Aragonese',

            'fy' => 'Frisian',

            'gu' => 'Gujarati',

            'ik' => 'Inupiaq',

            'ja' => '日本語',

            'ko' => '한국어/조선말',

            'lg' => 'Ganda',

            'nl' => 'Nederlands',

            'os' => 'Ossetian; Ossetic',

            'el' => 'ελληνικά',

            'bn' => 'বাংলা',

            'cr' => 'Cree',

            'km' => 'Khmer',

            'lo' => 'Lao',

            'nd' => 'Ndebele',

            'ne' => 'Nepali',

            'sc' => 'Sardinian',

            'sw' => 'Kiswahili',

            'tl' => 'Tagalog',

            'ur' => 'اردو',

            'ee' => 'Èʋegbe',

            'aa' => 'Afar',

            'co' => 'Corsican',

            'et' => 'Eesti',

            'is' => 'Íslenska',

            'ks' => 'Kashmiri',

            'kr' => 'Kanuri',

            'ky' => '??????',

            'kj' => 'Kuanyama',

            'nr' => 'Ndebele',

            'or' => 'Oriya',

            'wo' => 'Wolof',

            'za' => 'Zhuang',

            'ar' => 'العربية',

            'cv' => 'Chuvash',

            'fo' => 'Faroese',

            'hr' => 'Hrvatski',

            'ms' => 'Bahasa melayu',

            'nb' => 'Bokmål',

            'rn' => 'Kirundi',

            'sn' => 'Shona',

            'st' => 'Sotho',

            'tr' => 'Türkçe',

            'am' => 'Amharic',

            'fa' => 'فارسی',

            'hy' => 'Armenian',

            'pa' => 'ਪੰਜਾਬੀ',

            'as' => 'Assamese',

            'ia' => 'Interlingua',

            'lv' => 'Latviešu',

            'lu' => 'Luba-Katanga',

            'mr' => 'Marathi',

            'mn' => 'Mongolian',

            'pt' => 'Português',

            'th' => 'ภาษาไทย',

            'tk' => 'Turkmen',

            've' => 'Venda',

            'dv' => 'Divehi',

            'gv' => 'Manx',

            'kl' => 'Kalaallisut',

            'kk' => 'қазақ',

            'lt' => 'Lietuvių',

            'my' => 'Burmese',

            'sl' => 'Slovenščina',

            'sd' => 'Sindhi',

            'cn' => '广州话 / 廣州話',

            'hi' => 'हिन्दी',

            'cy' => 'Cymraeg',

            'ht' => 'Haitian; Haitian Creole',

            'iu' => 'Inuktitut',

            'jv' => 'Javanese',

            'mh' => 'Marshall',

            'sa' => 'Sanskrit',

            'ss' => 'Swati',

            'te' => 'తెలుగు',

            'kg' => 'Kongo',

            'ml' => 'Malayalam',

            'uz' => 'ozbek',

            'sg' => 'Sango',

            'xh' => 'Xhosa',

            'es' => 'Español',

            'su' => 'Sundanese',

            'ug' => 'Uighur',

            'yi' => 'Yiddish',

            'yo' => 'Èdè Yorùbá',

            'zh' => '普通话',

            'he' => 'עִבְרִית',

            'bo' => 'Tibetan',

            'ak' => 'Akan',

            'mo' => 'Moldavian',

            'ng' => 'Ndonga',

            'dz' => 'Dzongkha',

            'ff' => 'Fulfulde',

            'gd' => 'Gaelic',

            'ga' => 'Gaeilge',

            'gl' => 'Galego',

            'nv' => 'Navajo',

            'oc' => 'Occitan',

            'ro' => 'Română',

            'ta' => 'தமிழ்',

            'tn' => 'Tswana',

            'bg' => 'български език'

        ];
    }

    static function format($bytes, $precision = 2): string
    {
        $units = array('B', 'KB', 'MB', 'GB');

        $bytes = max($bytes * 1024 * 1024, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);

        $bytes /= pow(1024, $pow);

        return round($bytes, $precision) . ' ' . $units[$pow];
    }
}
