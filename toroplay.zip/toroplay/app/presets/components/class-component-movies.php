<?php

namespace TOROPLAY\components;

class movies extends helpers
{
    protected $id;

    function __construct($post_id)
    {
        $this->id = $post_id;
    }

    function thumbnail($size, $alt = ''): string
    {
        $term   = get_post_meta($this->id, 'poster_hotlink', true);
        $result = '';

        if (get_the_post_thumbnail($this->id, 'medium')) {
            $img_atts = wp_get_attachment_image_src(get_post_thumbnail_id($this->id), 'medium');
            $result = '<img src="' . $img_atts[0] . '" loading="lazy" alt="' . $alt . '" />';
        } elseif ($term) {
            if (filter_var($term, FILTER_VALIDATE_URL) === FALSE) {
                if (in_array($size, $this->image_pts())) {
                    $size = $size;
                } else {
                    $size = 'original';
                }
                $result = '<img src="' . $this->image_bss() . $size . $term . '" loading="lazy" alt="' . $alt . '" />';
            } else {
                $result = '<img src="' . $term . '" loading="lazy" alt="' . $alt . '" />';
            }
        } else {
            $result = '<img src="' . TOROPLAY_DIR_URI . 'resources/assets/img/poster.svg" loading="lazy" alt="' . $alt . '" />';
        }

        return $result;
    }

    function backdrop($size, $alt = ''): string
    {
        $term = get_post_meta($this->id, 'backdrop_hotlink', true);
        $result = '';

        if ($term != false) {
            if (in_array($size, $this->image_bds())) {
                $size = $size;
            } else {
                $size = 'original';
            }

            $result = '<img class="TPostBg" src="' . $this->image_bss() . $size . $term . '" loading="lazy" alt="' . $alt . '" />';
        }

        return $result;
    }

    function trailer(): object
    {
        $term = get_post_meta($this->id, 'field_trailer', true);

        $has = false;
        $result = '';

        if ($term != false) {
            $has = true;
            $result = $term;
        }

        return (object) [
            'has' => (bool)$has,
            'results' => (string) $result
        ];
    }

    function content(): object
    {
        $content = get_the_content($this->id);

        $has = false;
        $result = '';

        if ($content != false) {
            $has = true;
            $result = strip_tags($content);
        }

        return (object) [
            'has' => (bool)$has,
            'results' => (string) $result
        ];
    }

    function excerpt(): object
    {
        $excerpt = get_the_excerpt($this->id);

        $has = false;
        $result = '';

        if ($excerpt != false) {
            $has = true;
            $result = strip_tags($excerpt);
        }

        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    function original(): object
    {
        $term = get_post_meta($this->id, 'field_title', true);

        $has = false;
        $result = '';

        if ($term != false) {
            $has = true;
            $result = $term;
        }


        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    function minutes(): object
    {
        $term = get_post_meta($this->id, 'field_runtime', true);

        $has = false;
        $result = '';

        if ($term != false) {
            $has = true;
            $result = $term;
        }


        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    function premiere(): object
    {
        $term = get_post_meta($this->id, 'field_date', true);

        $has = false;
        $result = '';

        if ($term != false) {
            $has = true;

            $result = date_i18n(get_option('date_format'), strtotime($term));
        }

        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    function release(): object
    {
        $term = get_post_meta($this->id, 'field_release_year', true);
        $term = $term !== false ? $term : false;

        $has = false;
        $result = '';

        if ($term != false) {
            $has = true;

            $term = explode('-', $term);
            $result = $term[0];
        }


        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    function ranking(): object
    {
        $term = get_post_meta($this->id, 'rating', true);

        $has = false;
        $result = '';

        if ($term != false) {
            $has = true;
            $result = $term;
        }


        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    function director(): object
    {
        $terms = get_the_terms($this->id, 'directors');

        $has = false;
        $result = '';

        if ($terms != false) {
            $has = true;
            $result = [];
            foreach ($terms as $term) {
                $link = esc_url(get_term_link($term));
                $result[] = '<a aria-label="' . $term->name . '" href="' . $link . '">' . $term->name . '</a>';
            }

            $result = implode(', ', $result);
        }


        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    function genres(): object
    {
        $terms = get_the_terms($this->id, 'category');

        $has = false;
        $result = '';

        if ($terms != false) {
            $has = true;
            $result = [];

            foreach ($terms as $term) {
                $link = esc_url(get_term_link($term));
                $result[] = '<a aria-label="' . $term->name . '" href="' . $link . '">' . $term->name . '</a>';
            }

            $result = implode(', ', $result);
        }

        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    function casts(): object
    {
        $terms = get_the_terms($this->id, 'cast');

        $has = false;
        $result = '';

        if ($terms != false) {
            $has = true;

            $result = [];
            foreach ($terms as $term) {
                $link = esc_url(get_term_link($term));
                $result[] = '<a aria-label="' . $term->name . '" href="' . $link . '">' . $term->name . '</a>';
            }

            $result = implode(', ', $result);
        }

        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    function views(): object
    {
        $term = get_post_meta($this->id, 'views', true);

        $has = false;
        $result = '';

        if ($term != false) {
            $has = true;
            $result = $term;
        }


        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    function tags(): object
    {
        $terms = get_the_tag_list('', ', ', '', $this->id);

        $has = false;
        $result = '';

        if ($terms != false) {
            $has = true;

            $result = $terms;
        }

        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    function casts_raw($size): object
    {
        $terms = get_the_terms($this->id, 'cast');

        $has = false;
        $result = array();

        if ($terms != false) {
            $has = true;
            $result = [];
            foreach ($terms as $index => $term) {
                $link = esc_url(get_term_link($term));

                if (get_term_meta($term->term_id, 'image_hotlink', true) != '') {
                    if (filter_var(get_term_meta($term->term_id, 'image_hotlink', true), FILTER_VALIDATE_URL)) {
                        $src = get_term_meta($term->term_id, 'image_hotlink', true);
                    } else {
                        $src = $this->image_bss() . $size . get_term_meta($term->term_id, 'image_hotlink', true);
                    }
                } else if (get_term_meta($term->term_id, 'image', true) != '') {
                    $src = wp_get_attachment_url(get_term_meta($term->term_id, 'image', true));
                } else {
                    $src = TOROPLAY_DIR_URI . 'resources/assets/img/cnt/cast.png';
                }

                $result[$index]['url'] = $link;
                $result[$index]['nme'] = $term->name;
                $result[$index]['src'] = $src;
            }
        }

        return (object) [
            'has' => (bool) $has,
            'results' => (array) $result
        ];
    }

    function format_links(): object
    {
        $terms = (int) get_post_meta($this->id, 'trgrabber_tlinks', true);

        $has = false;
        $result = array();

        if ($terms > 0) {
            $has = true;

            $terms = (int) get_post_meta($this->id, 'trgrabber_tlinks', true) == '' ? 0 : get_post_meta($this->id, 'trgrabber_tlinks', true) - 1;

            for ($i = 0; $i <= $terms; $i++) {
                $data = get_post_meta($this->id, 'trglinks_' . $i, true);
                $term = unserialize($data);

                $type = $term['type'] ?? 1;
                $link = base64_decode($term['link']) ?? null;

                if ($type == 2 and !is_null($link)) {
                    $result[$i]['label'] = get_term($term['lang'], 'language')->name ?? null;
                    $result[$i]['link']['url'] = base64_encode($link);

                    if (filter_var($link, FILTER_VALIDATE_URL)) {
                        $result[$i]['link']['hts'] = parse_url($link, PHP_URL_HOST);
                    } else {
                        $result[$i]['link']['hts'] = null;
                    }

                    $result[$i]['link']['opt'] = $i;
                    $result[$i]['link']['srv'] = get_term($term['server'], 'server')->name ?? null;
                    $result[$i]['link']['qly'] = get_term($term['quality'], 'quality')->name ?? null;

                    $result[$i]['link']['lmt'] = base64_encode(json_encode([
                        'iat' => time(),
                        'exp' => time() + (60 * 5),
                        'lmt' => [
                            'id' => $this->id
                        ]
                    ]));
                }
            }
        }

        if (empty($result)) {
            $has = false;
        }

        return (object) [
            'has' => (bool) $has,
            'results' => (array) $result
        ];
    }

    function format_videos(): object
    {
        $terms = (int) get_post_meta($this->id, 'trgrabber_tlinks', true);

        $has = false;
        $result = array();

        if ($terms > 0) {
            $has = true;

            $terms = (int) get_post_meta($this->id, 'trgrabber_tlinks', true) == '' ? 0 : get_post_meta($this->id, 'trgrabber_tlinks', true) - 1;

            for ($i = 0; $i <= $terms; $i++) {
                $data = get_post_meta($this->id, 'trglinks_' . $i, true);
                $term = unserialize($data);

                $type = $term['type'] ?? 1;
                $link = base64_decode($term['link']) ?? null;

                if ($type == 1 and !is_null($link)) {
                    $lang = get_term($term['lang'], 'language')->term_id ?? 1;

                    $result[$lang]['label'] = get_term($term['lang'], 'language')->name ?? null;
                    $result[$lang]['group'] = $lang;

                    $result[$lang]['link'][$i]['url'] = base64_encode($link);

                    if (filter_var($link, FILTER_VALIDATE_URL)) {
                        $result[$lang]['link'][$i]['hts'] = parse_url($link, PHP_URL_HOST);
                    } else {
                        $result[$lang]['link'][$i]['hts'] = null;
                    }

                    $result[$lang]['link'][$i]['opt'] = $i;
                    $result[$lang]['link'][$i]['srv'] = get_term($term['server'], 'server')->name ?? null;
                    $result[$lang]['link'][$i]['qly'] = get_term($term['quality'], 'quality')->name ?? null;

                    $result[$lang]['link'][$i]['lmt'] = base64_encode(json_encode([
                        'iat' => time(),
                        'exp' => time() + (60 * 5),
                        'lmt' => [
                            'id' => $this->id
                        ]
                    ]));
                }
            }
        }

        if (empty($result)) {
            $has = false;
        }

        return (object) [
            'has' => (bool) $has,
            'results' => (array) $result
        ];
    }

    /** temp */
    function set_views(): void
    {
        $term = (int) get_post_meta($this->id, 'views', true);
        $term++;

        update_post_meta($this->id, 'views', $term);
    }
}
