<?php

namespace TOROPLAY\components;

class seasons extends helpers
{
    protected $id;
    protected $post;

    function __construct($term, $post_id)
    {
        $this->id = $term;
        $this->post = $post_id;
    }

    function thumbnail($size, $alt = ''): string
    {
        if (get_term_meta($this->id, 'poster_path_hotlink', true) != '') {
            if (filter_var(get_term_meta($this->id, 'poster_path_hotlink', true), FILTER_VALIDATE_URL)) {
                $src = get_term_meta($this->id, 'poster_path_hotlink', true);
            } else {
                $src = $this->image_bss() . $size . get_term_meta($this->id, 'poster_path_hotlink', true);
            }
        } else if (get_term_meta($this->id, 'poster_path', true) != '') {
            $src = wp_get_attachment_url(get_term_meta($this->id, 'poster_path', true));
        } else {
            $src = TOROPLAY_DIR_URI . 'resources/assets/img/cnt/poster.svg';
        }

        $term = $src;
        $result = '';

        if ($term != false) {
            $result = '<img src="' . $term . '" loading="lazy" alt="' . $alt . '" />';
        }

        return $result;
    }

    function backdrop($size, $alt = ''): string
    {
        $term = get_post_meta($this->post, 'backdrop_hotlink', true);
        $result = '';

        if ($term != false) {
            if (in_array($size, $this->image_bds())) {
                $size = $size;
            } else {
                $size = 'original';
            }

            $result = '<img class="TPostBg" src="' . $this->image_bss() . $size . $term . '" loading="lazy" alt="' . $alt . '" />';
        }

        return $result;
    }

    function minutes(): object
    {
        $term = get_post_meta($this->post, 'field_runtime', true);

        $has = false;
        $result = '';

        if ($term[0] != false) {
            $has = true;
            $result = $term[0] . 'm';
        }


        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    function status(): object
    {
        $term = get_post_meta($this->post, 'status', true);

        $has = false;
        $result = '';

        if ($term != false) {
            $has = true;
            $result = $term;
        }


        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    /** terms */
    function name(): object
    {
        $term = get_term_meta($this->id, 'name', true);

        $has = false;
        $result = '';

        if ($term != false) {
            $has = true;
            $result = $term;
        }


        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    function date(): object
    {
        $term = get_term_meta($this->id, 'air_date', true);

        $has = false;
        $result = '';

        if ($term != false) {
            $has = true;
            $result = date_i18n(get_option('date_format'), strtotime($term));
        }


        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    function views(): object
    {
        $term = get_term_meta($this->id, 'views', true);

        $has = false;
        $result = '';

        if ($term != false) {
            $has = true;
            $result = $term;
        }


        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    function release(): object
    {
        $term = get_term_meta($this->id, 'air_date', true);
        $term = $term !== false ? $term : false;

        $has = false;
        $result = '';

        if ($term != false) {
            $has = true;

            $term = explode('-', $term);
            $result = $term[0];
        }


        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    function overview(): object
    {
        $content = get_term_meta($this->id, 'overview', true);

        $has = false;
        $result = '';

        if ($content != false) {
            $has = true;
            $result = strip_tags($content);
        }

        return (object) [
            'has' => (bool)$has,
            'results' => (string) $result
        ];
    }

    function season_number($format = '%02d'): object
    {
        $term = (int) get_term_meta($this->id, 'season_number', true);

        $has = false;
        $result = '';

        if ($term !== false) {
            $has = true;
            $result = sprintf($format, $term);
        }


        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    function season_special($format = '%02d'): object
    {
        $term = (int) get_term_meta($this->id, 'season_special', true);

        $has = false;
        $result = '';

        if ($term !== false) {
            $has = true;
            $result = sprintf($format, $term);
        }


        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    function number_of_episodes($format = '%02d'): object
    {
        $term = (int) get_term_meta($this->id, 'number_of_episodes', true);

        $has = false;
        $result = '';

        if ($term !== false) {
            $has = true;
            $result = sprintf($format, $term);
        }


        return (object) [
            'has' => (bool) $has,
            'results' => (string) $result
        ];
    }

    /** temp */
    function set_views(): void
    {
        $term = (int) get_term_meta($this->id, 'views', true);
        $term++;

        update_term_meta($this->id, 'views', $term);
    }
}
