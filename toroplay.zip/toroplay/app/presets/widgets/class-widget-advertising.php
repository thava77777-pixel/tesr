<?php

add_action('widgets_init', function () {

    register_widget('widget_advertising');
});

class widget_advertising extends WP_Widget
{

    function __construct()
    {
        $widget_ops = array(
            'classname' => 'widget_advertising'
        );

        parent::__construct('widget_advertising', 'ToroPlay Advertising', $widget_ops);
    }


    function form($instance): void
    {
        $title     = isset($instance['title']) ? (string) esc_attr($instance['title']) : '';

        $desktop    = isset($instance['desktop']) ?  (string) $instance['desktop'] : '<img src="' . TOROPLAY_DIR_URI . 'resources/assets/img/cnt/toroplay-300.png" alt="">';
        $mobile     = isset($instance['mobile']) ? (string) $instance['mobile'] : '<img src="' . TOROPLAY_DIR_URI . 'resources/assets/img/cnt/toroplay-300.png" alt="">';

        echo '<p><label for="' . $this->get_field_id('title') . '"> ' . __('Title', 'toroplay') . '</label><input class="widefat" id="' . $this->get_field_id('title') . '" name="' . $this->get_field_name('title') . '" type="text" value="' . esc_attr($title) . '"></p>';

        echo '<p><label for="' . $this->get_field_id('desktop') . '"> ' . __('Desktop', 'toroplay') . '</label><textarea class="widefat" rows="8" cols="20" id="' . $this->get_field_id('desktop') . '" name="' . $this->get_field_name('desktop') . '">' . esc_attr($desktop) . '</textarea></p>';
        echo '<p><label for="' . $this->get_field_id('mobile') . '"> ' . __('Mobile', 'toroplay') . '</label><textarea class="widefat" rows="8" cols="20" id="' . $this->get_field_id('mobile') . '" name="' . $this->get_field_name('mobile') . '">' . esc_attr($mobile) . '</textarea></p>';
    }



    function update($new_instance, $old_instance): array
    {
        $instance = $old_instance;
        $instance['title'] = sanitize_text_field($new_instance['title']);

        $instance['desktop'] = $new_instance['desktop'];
        $instance['mobile'] = $new_instance['mobile'];

        return $instance;
    }


    function widget($args, $instance): void
    {

        if (!empty($instance['title'])) {
            echo $args['before_widget'];

            echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];

            if (!wp_is_mobile()) {
                $desktop  = isset($instance['desktop']) ? (string) $instance['desktop'] : '';

                echo '<div class="Dvr-300">' . $desktop . '</div>';
            } else {
                $mobile   = isset($instance['mobile']) ? (string) $instance['mobile'] : '';

                echo '<div class="Dvr-300">' . $mobile . '</div>';
            }

            echo $args['after_widget'];
        } else {
            if (!wp_is_mobile()) {
                $desktop  = isset($instance['desktop']) ? (string) $instance['desktop'] : '';

                echo '<div class="Dvr-300">' . $desktop . '</div>';
            } else {
                $mobile   = isset($instance['mobile']) ? (string) $instance['mobile'] : '';

                echo '<div class="Dvr-300">' . $mobile . '</div>';
            }
        }
    }
}
