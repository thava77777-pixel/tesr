<?php

add_action('widgets_init', function () {

    register_widget('widget_movies');
});

class widget_movies extends WP_Widget
{

    function __construct()
    {
        $widget_ops = array(
            'classname' => 'widget_movies'
        );

        parent::__construct('widget_movies', 'ToroPlay Movies', $widget_ops);
    }


    function form($instance): void
    {
        $title      = !empty($instance['title']) ? (string) $instance['title'] : '';

        $design     = isset($instance['design']) ? (int)    $instance['design'] : '';
        $number     = isset($instance['number']) ? (int)   $instance['number'] : 9;

        $order      = isset($instance['order']) ?  (string) $instance['order'] : '';

        echo '<p><label for="' . $this->get_field_id('title') . '"> ' . __('Title', 'toroplay') . '</label><input class="widefat" id="' . $this->get_field_id('title') . '" name="' . $this->get_field_name('title') . '" type="text" value="' . esc_attr($title) . '"></p>';
        echo '<p><label for="' . $this->get_field_id('number') . '"> ' . __('Number', 'toroplay') . '</label><input class="widefat" id="' . $this->get_field_id('number') . '" name="' . $this->get_field_name('number') . '" type="number" step="3" min="3" value="' . esc_attr($number) . '"></p>';

        echo '<p> <label for="' . $this->get_field_id('design') . '">' . __('Design', 'toroplay') . '</label> <select id="' . $this->get_field_id('design') . '" name="' . $this->get_field_name('design') . '" class="widefat"> <option value="1" ' . selected($design, 1, false) . '>' . __('Design Primary', 'toroplay') . '</option> <option value="2" ' . selected($design, 2, false) . ' >' . __('Design Secondary', 'toroplay') . '</option> </select> </p>';
        echo '<p> <label for="' . $this->get_field_id('order') . '">' . __('Order', 'toroplay') . ':</label> <select id="' . $this->get_field_id('order') . '" name="' . $this->get_field_name('order') . '" class="widefat"> <option value="ASC" ' . selected($order, 'ASC', false) . ' >' . __('Ascending', 'toroplay') . '</option> <option value="DESC" ' . selected($order, 'DESC', false) . ' >' . __('Descending', 'toroplay') . '</option> </select> </p>';
    }



    function update($new_instance, $old_instance): array
    {
        foreach ($new_instance as $k => $v) {
            $updated_instance[$k] = sanitize_text_field($v);
        }

        // $updated_instance['categories'] = strip_tags(implode(',', $new_instance['categories']));

        return $updated_instance;
    }


    function widget($args, $instance): void
    {
        echo $args['before_widget'];

        if (!empty($instance['title'])) {
            echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
        }

        $order      = isset($instance['order']) ? (string) $instance['order'] : 'DESC';

        $design     = isset($instance['design']) ? (int) $instance['design'] : 1;
        $number     = isset($instance['number']) ? (int) $instance['number'] : 3;


        $results = new WP_Query(array(
            'post_type'           => array('movies'),
            'posts_per_page'      => $number,
            'order'               => $order,
            'post_status'         => 'publish',
            'no_found_rows'       => true,
            'ignore_sticky_posts' => true,
        ));

        switch ($design) {
            case 1:
                if ($results->have_posts()) {
                    echo '<ul class="MovieList">';

                    while ($results->have_posts()) : $results->the_post();

                        get_template_part('resources/views/components/wdgt', 'mvs1');

                    endwhile;

                    echo '</ul>';
                }

                break;
            case 2:
                if ($results->have_posts()) {
                    echo '<div class="TpSbList">';
                    echo '<ul class="MovieList Rows AF A04">';

                    while ($results->have_posts()) : $results->the_post();

                        get_template_part('resources/views/components/wdgt', 'mvs2');

                    endwhile;

                    echo '</ul>';
                    echo '</div>';
                }

                break;
        }

        echo $args['after_widget'];
    }
}
