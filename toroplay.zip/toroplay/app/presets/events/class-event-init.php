<?php

namespace TOROPLAY\events;

class init
{

    function __construct()
    {
        add_action('setup_theme', array($this, 'setup_theme'), 10);
        add_action('after_setup_theme', array($this, 'setup_support'), 10);

        add_action('init', array($this, 'init_menus'), 5);

        add_action('after_switch_theme', array($this, 'standards'), 10);
    }

    static function setup_theme(): void
    {
    }

    static function setup_support(): void
    {
        add_theme_support('automatic-feed-links');
        add_theme_support('title-tag');

        add_theme_support('custom-logo');
        add_theme_support('post-thumbnails');

        add_theme_support('custom-header');
        add_theme_support('custom-background');
    }

    static function init_menus(): void
    {
        register_nav_menus(
            array(
                'header' => __('Menu Header', 'toroplay'),
                'footer' => __('Menu Footer', 'toroplay')
            )
        );
    }

    static function standards(): void
    {
        if (version_compare('7.0.0', phpversion(), '>=')) {
            wp_die('You must be using PHP 7.0.0 or greater.', 'Invalid PHP version');
        }

        if (version_compare('5.5.0', get_bloginfo('version'), '>=')) {
            wp_die('You must be using WordPress 5.5.0 or greater.', 'Invalid WordPress version');
        }

        if (!extension_loaded('mysqli')) {
            // wp_die('.', '');
        }

        if (!extension_loaded('pdo')) {
            // wp_die('.', '');
        }

        if (!extension_loaded('curl')) {
            // wp_die('.', '');
        }

        if (!extension_loaded('mbstring')) {
            // wp_die('.', '');
        }

        if (!extension_loaded('zip')) {
            // wp_die('.', '');
        }

        if (ini_get('allow_url_fopen') != '1' && ini_get('allow_url_fopen') != 'On') {
            // wp_die('.', '');
        }
    }
}
