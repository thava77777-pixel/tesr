<?php

function theme_slug_sanitize_select($input, $setting)
{
    $input = sanitize_key($input);
    $choices = $setting->manager->get_control($setting->id)->choices;
    return (array_key_exists($input, $choices) ? $input : $setting->default);
}

function theme_slug_sanitize_checkbox($input)
{
    return ((isset($input) && true == $input) ? true : false);
}


function tp_remove_sections($wp_customize)
{
    $wp_customize->remove_section('header_image');
    $wp_customize->remove_section('background_image');
    $wp_customize->remove_section('colors');
}

function tp_add_customizer_panels($wp_customize)
{
    $wp_customize->add_panel('tp_options', array(
        'title' => 'Toroplay',
        'priority' => 30,
        'capability' => 'edit_theme_options',
    ));
}

function tp_add_customizer_sections($wp_customize)
{
    $wp_customize->add_section('tp_layout_opts', array(
        'title'      => 'Layout',
        'panel'      => 'tp_options',
        'priority'   => 1,
        'capability' => 'edit_theme_options'
    ));

    $wp_customize->add_section('tp_footer_opts', array(
        'title'      => 'Footer',
        'panel'      => 'tp_options',
        'priority'   => 1,
        'capability' => 'edit_theme_options'
    ));

    $wp_customize->add_section('tp_player_opts', array(
        'title'      => 'Player',
        'panel'      => 'tp_options',
        'priority'   => 1,
        'capability' => 'edit_theme_options'
    ));

    $wp_customize->add_section('tp_pages_opts', array(
        'title'      => 'Pages',
        'panel'      => 'tp_options',
        'priority'   => 1,
        'capability' => 'edit_theme_options'
    ));

    $wp_customize->add_section('tp_home_opts', array(
        'title'      => 'Home ( new in v2.0.0 )',
        'panel'      => 'tp_options',
        'priority'   => 1,
        'capability' => 'edit_theme_options'
    ));

    $wp_customize->add_section('tp_images_opts', array(
        'title'      => 'Images',
        'panel'      => 'tp_options',
        'priority'   => 1,
        'capability' => 'edit_theme_options'
    ));
}

function tp_register_layout_controls($wp_customize)
{
    $wp_customize->add_setting('tp_layout_sidebar', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_layout_sidebar', array(
        'label'    => 'Sidebar',
        'section'  => 'tp_layout_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'TpRCol' => 'Right',
            'TpLCol' => 'Left',
            'NoSdbr' => 'None',
        )
    ));

    $wp_customize->add_setting('tp_layout_border', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'theme_slug_sanitize_checkbox',
        'transport'         => 'refresh'
    ));
    $wp_customize->add_control('tp_layout_border', array(
        'label'    => 'Remove border radius',
        'section'  => 'tp_layout_opts',
        'priority' => 2,
        'type'     => 'checkbox'
    ));

    $wp_customize->add_setting('tp_layout_boxed', array(
        'type'              => 'option',
        'default'           => true,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'theme_slug_sanitize_checkbox',
        'transport'         => 'refresh'
    ));
    $wp_customize->add_control('tp_layout_boxed', array(
        'label'    => 'Boxed',
        'section'  => 'tp_layout_opts',
        'priority' => 2,
        'type'     => 'checkbox'
    ));

    $wp_customize->add_setting('tp_layout_fullw', array(
        'type'              => 'option',
        'default'           => false,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'theme_slug_sanitize_checkbox',
        'transport'         => 'refresh'
    ));
    $wp_customize->add_control('tp_layout_fullw', array(
        'label'    => 'Full Width',
        'section'  => 'tp_layout_opts',
        'priority' => 2,
        'type'     => 'checkbox'
    ));
}

function tp_register_footer_controls($wp_customize)
{
    $wp_customize->add_setting('tp_footer_text', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'wp_filter_nohtml_kses'
    ));
    $wp_customize->add_control('tp_footer_text', array(
        'label'    => 'Text',
        'section'  => 'tp_footer_opts',
        'priority' => 2,
        'type'     => 'textarea',
    ));

    $wp_customize->add_setting('tp_footer_instagram', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'wp_filter_nohtml_kses'
    ));
    $wp_customize->add_control('tp_footer_instagram', array(
        'label'    => 'Instagram',
        'section'  => 'tp_footer_opts',
        'priority' => 2,
        'type'     => 'text',
    ));

    $wp_customize->add_setting('tp_footer_facebook', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'wp_filter_nohtml_kses'
    ));
    $wp_customize->add_control('tp_footer_facebook', array(
        'label'    => 'Facebook',
        'section'  => 'tp_footer_opts',
        'priority' => 2,
        'type'     => 'text',
    ));

    $wp_customize->add_setting('tp_footer_twitter', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'wp_filter_nohtml_kses'
    ));
    $wp_customize->add_control('tp_footer_twitter', array(
        'label'    => 'Twitter',
        'section'  => 'tp_footer_opts',
        'priority' => 2,
        'type'     => 'text',
    ));

    $wp_customize->add_setting('tp_footer_tumblr', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'wp_filter_nohtml_kses'
    ));
    $wp_customize->add_control('tp_footer_tumblr', array(
        'label'    => 'Tumblr',
        'section'  => 'tp_footer_opts',
        'priority' => 2,
        'type'     => 'text',
    ));

    $wp_customize->add_setting('tp_footer_reddit', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'wp_filter_nohtml_kses'
    ));
    $wp_customize->add_control('tp_footer_reddit', array(
        'label'    => 'Reddit',
        'section'  => 'tp_footer_opts',
        'priority' => 2,
        'type'     => 'text',
    ));
}

function tp_register_player_controls($wp_customize)
{
    $wp_customize->add_setting('tp_player_advertising', array(
        'type'              => 'option',
        'default'           => false,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'theme_slug_sanitize_checkbox',
        'transport'         => 'refresh'
    ));

    $wp_customize->add_control('tp_player_advertising', array(
        'label'    => 'Enable Player Advertising',
        'section'  => 'tp_player_opts',
        'priority' => 2,
        'type'     => 'checkbox'
    ));

    $wp_customize->add_setting('tp_player_fake', array(
        'type'              => 'option',
        'default'           => false,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'theme_slug_sanitize_checkbox',
        'transport'         => 'refresh'
    ));

    $wp_customize->add_control('tp_player_fake', array(
        'label'    => 'Enable Player Fake',
        'section'  => 'tp_player_opts',
        'priority' => 2,
        'type'     => 'checkbox'
    ));

    $wp_customize->add_setting('tp_player_fake_blank', array(
        'type'              => 'option',
        'default'           => false,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'theme_slug_sanitize_checkbox',
        'transport'         => 'refresh'
    ));

    $wp_customize->add_control('tp_player_fake_blank', array(
        'label'    => 'Enable Player Fake blank',
        'section'  => 'tp_player_opts',
        'priority' => 2,
        'type'     => 'checkbox'
    ));

    $wp_customize->add_setting('tp_player_fake_url', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'wp_filter_nohtml_kses',
        'transport'         => 'refresh'
    ));

    $wp_customize->add_control('tp_player_fake_url', array(
        'label'    => 'Player Fake url',
        'section'  => 'tp_player_opts',
        'priority' => 2,
        'type'     => 'text',
    ));

    $wp_customize->add_setting('tp_player_advertising_code', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'transport'         => 'refresh'
    ));

    $wp_customize->add_control('tp_player_advertising_code', array(
        'label'    => 'Advertising code',
        'section'  => 'tp_player_opts',
        'priority' => 2,
        'type'     => 'textarea',
    ));
}

function tp_register_pages_controls($wp_customize)
{
    $wp_customize->add_setting('tp_pages_pg_pages', array(
        'type'                  => 'option',
        'default'               => 24,
        'capability'            => 'edit_theme_options',
        'sanitize_callback'     => 'absint',
        'transport'             => 'refresh'
    ));
    $wp_customize->add_control('tp_pages_pg_pages', array(
        'label'      => 'Number of content pages',
        'section'    => 'tp_pages_opts',
        'priority'   => 2,
        'type'       => 'number',
    ));

    $wp_customize->add_setting('tp_pages_pg_search', array(
        'type'                  => 'option',
        'default'               => 24,
        'capability'            => 'edit_theme_options',
        'sanitize_callback'     => 'absint',
        'transport'             => 'refresh'
    ));
    $wp_customize->add_control('tp_pages_pg_search', array(
        'label'      => 'Number of content search',
        'section'    => 'tp_pages_opts',
        'priority'   => 2,
        'type'       => 'number',
    ));

    $wp_customize->add_setting('tp_pages_pg_category', array(
        'type'                  => 'option',
        'default'               => 24,
        'capability'            => 'edit_theme_options',
        'sanitize_callback'     => 'absint',
        'transport'             => 'refresh'
    ));
    $wp_customize->add_control('tp_pages_pg_category', array(
        'label'      => 'Number of content category',
        'section'    => 'tp_pages_opts',
        'priority'   => 2,
        'type'       => 'number',
    ));

    $wp_customize->add_setting('tp_pages_pg_taxonomy', array(
        'type'                  => 'option',
        'default'               => 24,
        'capability'            => 'edit_theme_options',
        'sanitize_callback'     => 'absint',
        'transport'             => 'refresh'
    ));
    $wp_customize->add_control('tp_pages_pg_taxonomy', array(
        'label'      => 'Number of content taxonomy',
        'section'    => 'tp_pages_opts',
        'priority'   => 2,
        'type'       => 'number',
    ));
}

function tp_register_home_controls($wp_customize)
{
    $wp_customize->add_setting('tp_home_letters_up', array(
        'type'              => 'option',
        'default'           => false,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'theme_slug_sanitize_checkbox',
        'transport'         => 'refresh'
    ));

    $wp_customize->add_control('tp_home_letters_up', array(
        'label'    => 'Enable letters ( above )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'checkbox'
    ));

    $wp_customize->add_setting('tp_home_letters_bt', array(
        'type'              => 'option',
        'default'           => false,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'theme_slug_sanitize_checkbox',
        'transport'         => 'refresh'
    ));

    $wp_customize->add_control('tp_home_letters_bt', array(
        'label'    => 'Enable letters ( below )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'checkbox'
    ));

    /** swiper sv1 */
    $wp_customize->add_setting('tp_home_swiper_sv1', array(
        'type'              => 'option',
        'default'           => false,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'theme_slug_sanitize_checkbox',
        'transport'         => 'refresh'
    ));

    $wp_customize->add_control('tp_home_swiper_sv1', array(
        'label'    => 'Enable swiper ( sv1 )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'checkbox'
    ));

    $wp_customize->add_setting('tp_home_swiper_sv1_type', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_home_swiper_sv1_type', array(
        'label'    => 'swiper sv1 ( Type )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'mvs' => 'Movies',
            'srs' => 'Series'
        )
    ));

    $wp_customize->add_setting('tp_home_swiper_sv1_order', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_home_swiper_sv1_order', array(
        'label'    => 'swiper sv1 ( Order )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'ASC' => 'Ascending',
            'DESC' => 'Descending'
        )
    ));

    $wp_customize->add_setting('tp_home_swiper_sv1_orderby', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_home_swiper_sv1_orderby', array(
        'label'    => 'swiper sv1 ( Order By )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'none' => 'None',
            'author' => 'Author',
            'Title' => 'Title',
            'name' => 'Name',
            'rand' => 'Rand'
        )
    ));

    $wp_customize->add_setting('tp_home_swiper_sv1_number', array(
        'type'              => 'option',
        'default'           => 6,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'absint',
        'transport'         => 'refresh'
    ));

    $wp_customize->add_control('tp_home_swiper_sv1_number', array(
        'label'    => 'swiper sv1 ( number )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'number'
    ));

    /** swiper sv2 */
    $wp_customize->add_setting('tp_home_swiper_sv2', array(
        'type'              => 'option',
        'default'           => false,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'theme_slug_sanitize_checkbox',
        'transport'         => 'refresh'
    ));

    $wp_customize->add_control('tp_home_swiper_sv2', array(
        'label'    => 'Enable swiper ( sv2 )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'checkbox'
    ));

    $wp_customize->add_setting('tp_home_swiper_sv2_type', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_home_swiper_sv2_type', array(
        'label'    => 'swiper sv2 ( Type )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'mvs' => 'Movies',
            'srs' => 'Series'
        )
    ));

    $wp_customize->add_setting('tp_home_swiper_sv2_order', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_home_swiper_sv2_order', array(
        'label'    => 'swiper sv2 ( Order )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'ASC' => 'Ascending',
            'DESC' => 'Descending'
        )
    ));

    $wp_customize->add_setting('tp_home_swiper_sv2_orderby', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_home_swiper_sv2_orderby', array(
        'label'    => 'swiper sv2 ( Order By )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'none' => 'None',
            'author' => 'Author',
            'Title' => 'Title',
            'name' => 'Name',
            'rand' => 'Rand'
        )
    ));

    $wp_customize->add_setting('tp_home_swiper_sv2_number', array(
        'type'              => 'option',
        'default'           => 6,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'absint',
        'transport'         => 'refresh'
    ));

    $wp_customize->add_control('tp_home_swiper_sv2_number', array(
        'label'    => 'swiper sv2 ( number )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'number'
    ));

    /** movies */
    $wp_customize->add_setting('tp_home_section_movies', array(
        'type'              => 'option',
        'default'           => false,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'theme_slug_sanitize_checkbox',
        'transport'         => 'refresh'
    ));

    $wp_customize->add_control('tp_home_section_movies', array(
        'label'    => 'Enable section ( movies )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'checkbox'
    ));

    $wp_customize->add_setting('tp_home_section_movies_url', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'wp_filter_nohtml_kses'
    ));
    $wp_customize->add_control('tp_home_section_movies_url', array(
        'label'    => 'section movies ( Url )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'text',
    ));

    $wp_customize->add_setting('tp_home_section_movies_name', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'wp_filter_nohtml_kses'
    ));
    $wp_customize->add_control('tp_home_section_movies_name', array(
        'label'    => 'section movies ( Name )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'text',
    ));

    $wp_customize->add_setting('tp_home_section_movies_order', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_home_section_movies_order', array(
        'label'    => 'section movies ( Order )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'ASC' => 'Ascending',
            'DESC' => 'Descending'
        )
    ));

    $wp_customize->add_setting('tp_home_section_movies_orderby', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_home_section_movies_orderby', array(
        'label'    => 'section movies ( Order By )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'none' => 'None',
            'author' => 'Author',
            'Title' => 'Title',
            'name' => 'Name',
            'rand' => 'Rand'
        )
    ));

    $wp_customize->add_setting('tp_home_section_movies_number', array(
        'type'              => 'option',
        'default'           => 10,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'absint',
        'transport'         => 'refresh'
    ));

    $wp_customize->add_control('tp_home_section_movies_number', array(
        'label'    => 'section movies ( number )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'number'
    ));

    /** series */
    $wp_customize->add_setting('tp_home_section_series', array(
        'type'              => 'option',
        'default'           => false,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'theme_slug_sanitize_checkbox',
        'transport'         => 'refresh'
    ));

    $wp_customize->add_control('tp_home_section_series', array(
        'label'    => 'Enable section ( series )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'checkbox'
    ));

    $wp_customize->add_setting('tp_home_section_series_url', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'wp_filter_nohtml_kses'
    ));
    $wp_customize->add_control('tp_home_section_series_url', array(
        'label'    => 'section series ( Url )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'text',
    ));

    $wp_customize->add_setting('tp_home_section_series_name', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'wp_filter_nohtml_kses'
    ));
    $wp_customize->add_control('tp_home_section_series_name', array(
        'label'    => 'section series ( Name )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'text',
    ));

    $wp_customize->add_setting('tp_home_section_series_order', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_home_section_series_order', array(
        'label'    => 'section series ( Order )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'ASC' => 'Ascending',
            'DESC' => 'Descending'
        )
    ));

    $wp_customize->add_setting('tp_home_section_series_orderby', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_home_section_series_orderby', array(
        'label'    => 'section series ( Order By )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'none' => 'None',
            'author' => 'Author',
            'Title' => 'Title',
            'name' => 'Name',
            'rand' => 'Rand'
        )
    ));

    $wp_customize->add_setting('tp_home_section_series_number', array(
        'type'              => 'option',
        'default'           => 10,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'absint',
        'transport'         => 'refresh'
    ));

    $wp_customize->add_control('tp_home_section_series_number', array(
        'label'    => 'section series ( number )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'number'
    ));

    /** seasons */
    $wp_customize->add_setting('tp_home_section_seasons', array(
        'type'              => 'option',
        'default'           => false,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'theme_slug_sanitize_checkbox',
        'transport'         => 'refresh'
    ));

    $wp_customize->add_control('tp_home_section_seasons', array(
        'label'    => 'Enable section ( seasons )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'checkbox'
    ));

    $wp_customize->add_setting('tp_home_section_seasons_url', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'wp_filter_nohtml_kses'
    ));
    $wp_customize->add_control('tp_home_section_seasons_url', array(
        'label'    => 'section seasons ( Url )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'text',
    ));

    $wp_customize->add_setting('tp_home_section_seasons_name', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'wp_filter_nohtml_kses'
    ));
    $wp_customize->add_control('tp_home_section_seasons_name', array(
        'label'    => 'section seasons ( Name )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'text',
    ));

    $wp_customize->add_setting('tp_home_section_seasons_order', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_home_section_seasons_order', array(
        'label'    => 'section seasons ( Order )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'ASC' => 'Ascending',
            'DESC' => 'Descending'
        )
    ));

    $wp_customize->add_setting('tp_home_section_seasons_number', array(
        'type'              => 'option',
        'default'           => 10,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'absint',
        'transport'         => 'refresh'
    ));

    $wp_customize->add_control('tp_home_section_seasons_number', array(
        'label'    => 'section seasons ( number )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'number'
    ));

    /** episodes */
    $wp_customize->add_setting('tp_home_section_episodes', array(
        'type'              => 'option',
        'default'           => false,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'theme_slug_sanitize_checkbox',
        'transport'         => 'refresh'
    ));

    $wp_customize->add_control('tp_home_section_episodes', array(
        'label'    => 'Enable section ( episodes )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'checkbox'
    ));

    $wp_customize->add_setting('tp_home_section_episodes_url', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'wp_filter_nohtml_kses'
    ));
    $wp_customize->add_control('tp_home_section_episodes_url', array(
        'label'    => 'section episodes ( Url )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'text',
    ));

    $wp_customize->add_setting('tp_home_section_episodes_name', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'wp_filter_nohtml_kses'
    ));
    $wp_customize->add_control('tp_home_section_episodes_name', array(
        'label'    => 'section episodes ( Name )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'text',
    ));

    $wp_customize->add_setting('tp_home_section_episodes_order', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_home_section_episodes_order', array(
        'label'    => 'section episodes ( Order )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'ASC' => 'Ascending',
            'DESC' => 'Descending'
        )
    ));

    $wp_customize->add_setting('tp_home_section_episodes_number', array(
        'type'              => 'option',
        'default'           => 10,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'absint',
        'transport'         => 'refresh'
    ));

    $wp_customize->add_control('tp_home_section_episodes_number', array(
        'label'    => 'section episodes ( number )',
        'section'  => 'tp_home_opts',
        'priority' => 2,
        'type'     => 'number'
    ));
}

function tp_register_images_controls($wp_customize)
{
    $wp_customize->add_setting('tp_images_pts_movies', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_images_pts_movies', array(
        'label'    => 'movies ( Thumbnail )',
        'section'  => 'tp_images_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'w154' => 'w154',
            'w185' => 'w185',
            'w342' => 'w342'
        )
    ));

    $wp_customize->add_setting('tp_images_bds_movies', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_images_bds_movies', array(
        'label'    => 'movies ( Backdrop )',
        'section'  => 'tp_images_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'w300' => 'w300',
            'w780' => 'w780'
        )
    ));


    $wp_customize->add_setting('tp_images_pts_series', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_images_pts_series', array(
        'label'    => 'series ( Thumbnail )',
        'section'  => 'tp_images_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'w154' => 'w154',
            'w185' => 'w185',
            'w342' => 'w342'
        )
    ));

    $wp_customize->add_setting('tp_images_bds_series', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_images_bds_series', array(
        'label'    => 'series ( Backdrop )',
        'section'  => 'tp_images_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'w300' => 'w300',
            'w780' => 'w780'
        )
    ));


    $wp_customize->add_setting('tp_images_pts_seasons', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_images_pts_seasons', array(
        'label'    => 'seasons ( Thumbnail )',
        'section'  => 'tp_images_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'w154' => 'w154',
            'w185' => 'w185',
            'w342' => 'w342'
        )
    ));

    $wp_customize->add_setting('tp_images_bds_seasons', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_images_bds_seasons', array(
        'label'    => 'seasons ( Backdrop )',
        'section'  => 'tp_images_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'w300' => 'w300',
            'w780' => 'w780'
        )
    ));


    $wp_customize->add_setting('tp_images_pts_episodes', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_images_pts_episodes', array(
        'label'    => 'episodes ( 1vs )',
        'section'  => 'tp_images_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'w154' => 'w154',
            'w185' => 'w185',
            'w342' => 'w342'
        )
    ));

    $wp_customize->add_setting('tp_images_bds_episodes', array(
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
    ));
    $wp_customize->add_control('tp_images_bds_episodes', array(
        'label'    => 'episodes ( 2vs )',
        'section'  => 'tp_images_opts',
        'priority' => 2,
        'type'     => 'select',
        'choices'  => array(
            'w300' => 'w300',
            'w780' => 'w780'
        )
    ));
}

add_action('customize_register', 'tp_remove_sections');

add_action('customize_register', 'tp_add_customizer_panels');
add_action('customize_register', 'tp_add_customizer_sections');

add_action('customize_register', 'tp_register_layout_controls');
add_action('customize_register', 'tp_register_footer_controls');
add_action('customize_register', 'tp_register_player_controls');
add_action('customize_register', 'tp_register_pages_controls');
add_action('customize_register', 'tp_register_home_controls');

add_action('customize_register', 'tp_register_images_controls');
