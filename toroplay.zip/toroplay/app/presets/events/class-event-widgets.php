<?php

namespace TOROPLAY\events;

class widgets
{

    function __construct()
    {
        add_action('init', array($this, 'init_widgets'), 1);
    }

    static function init_widgets(): void
    {
        register_sidebar(array(
            'name'          => __('Sidebar home page', 'toroplay'),
            'id'            => 'sidebar-home',
            'before_widget' => '<div id="%1$s" class="Wdgt %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="Title">',
            'after_title'   => '</div>'
        ));

        register_sidebar(array(
            'name'          => __('Sidebar pages page', 'toroplay'),
            'id'            => 'sidebar-pages',
            'before_widget' => '<div id="%1$s" class="Wdgt %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="Title">',
            'after_title'   => '</div>'
        ));


        register_sidebar(array(
            'name'          => __('Sidebar movies page', 'toroplay'),
            'id'            => 'sidebar-movies',
            'before_widget' => '<div id="%1$s" class="Wdgt %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="Title">',
            'after_title'   => '</div>'
        ));

        register_sidebar(array(
            'name'          => __('Sidebar series page', 'toroplay'),
            'id'            => 'sidebar-series',
            'before_widget' => '<div id="%1$s" class="Wdgt %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="Title">',
            'after_title'   => '</div>'
        ));

        register_sidebar(array(
            'name'          => __('Sidebar episodes page', 'toroplay'),
            'id'            => 'sidebar-episodes',
            'before_widget' => '<div id="%1$s" class="Wdgt %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="Title">',
            'after_title'   => '</div>'
        ));

        register_sidebar(array(
            'name'          => __('Sidebar seasons page', 'toroplay'),
            'id'            => 'sidebar-seasons',
            'before_widget' => '<div id="%1$s" class="Wdgt %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="Title">',
            'after_title'   => '</div>'
        ));
    }
}
