<?php

namespace TOROPLAY;

use TOROPLAY\presets\{
    loader
};

use TOROPLAY\events\{
    init,
    widgets
};

use TOROPLAY\components\{
    helpers
};

use TOROPLAY\app\{
    pri,
    pub
};

// use TOROPLAY\panels\{
//     index
// };

class app
{
    public $version = TP_VERSION;

    /** loader */
    protected $loader;

    public function __construct()
    {
        $this->dependencies();
        $this->instance();
    }

    /** beforeCreate */
    private function beforeCreate()
    {
    }

    public function created()
    {
        /** before */
        $this->beforeCreate();
        // $this->loader->add_action('after_setup_theme', $this->license, 'license');

        /** pri */

        /** pub */
    }

    /** beforeMount */
    private function beforeMount()
    {
        //
    }

    public function mounted()
    {
        /** before */
        $this->beforeMount();

        $this->loader->init();
    }

    private function dependencies()
    {
        /** presets */
        require_once TOROPLAY_DIR_PATH . 'app/presets/class-preset-loader.php';

        /** presets/events */
        require_once TOROPLAY_DIR_PATH . 'app/presets/events/class-event-init.php';
        require_once TOROPLAY_DIR_PATH . 'app/presets/events/class-event-widgets.php';

        /** presets:customize */
        require_once TOROPLAY_DIR_PATH . 'app/helpers/customize/class-color.php';
        require_once TOROPLAY_DIR_PATH . 'app/helpers/customize/class-multiple-checkbox.php';

        /** presets:customize */
        require_once TOROPLAY_DIR_PATH . 'app/presets/events/class-event-customize.php';

        /** presets/components */
        require_once TOROPLAY_DIR_PATH . 'app/presets/components/class-component-helpers.php';

        require_once TOROPLAY_DIR_PATH . 'app/presets/components/class-component-movies.php';
        require_once TOROPLAY_DIR_PATH . 'app/presets/components/class-component-series.php';

        require_once TOROPLAY_DIR_PATH . 'app/presets/components/class-component-seasons.php';
        require_once TOROPLAY_DIR_PATH . 'app/presets/components/class-component-episodes.php';

        /** presets/widgets */
        require_once TOROPLAY_DIR_PATH . 'app/presets/widgets/class-widget-advertising.php';
        require_once TOROPLAY_DIR_PATH . 'app/presets/widgets/class-widget-movies.php';
        require_once TOROPLAY_DIR_PATH . 'app/presets/widgets/class-widget-series.php';

        /** app */
        require_once TOROPLAY_DIR_PATH . 'app/class-app-pri.php';
        require_once TOROPLAY_DIR_PATH . 'app/class-app-pub.php';

        /** panels */
        // require_once TOROPLAY_DIR_PATH . 'app/panels/class-panels-index.php';
    }

    private function instance()
    {
        $this->loader    = new loader;

        $this->init      = new init();
        $this->widgets   = new widgets();

        $this->helpers   = new helpers();

        $this->pri       = new pri();
        $this->pub       = new pub();

        // $this->index    = new index();
    }
}
