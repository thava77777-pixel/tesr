<?php

namespace TOROPLAY\app;

class pub
{
    function __construct()
    {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_styles'), 10);
        add_action('wp_footer', array($this, 'enqueue_scripts'), 15);
    }

    static function enqueue_styles(): void
    {
        wp_dequeue_style('wp-block-library');
        wp_dequeue_style('wp-block-library-theme');
        wp_dequeue_style('wc-block-style');

        wp_enqueue_style(
            'tp-pub.css',
            TOROPLAY_DIR_URI . 'resources/assets/css/tp-pub.css',
            null,
            filemtime(TOROPLAY_DIR_PATH . 'resources/assets/css/tp-pub.css')
        );

        wp_enqueue_style(
            'font-awesome.css',
            TOROPLAY_DIR_URI . 'resources/assets/css/font-awesome.css',
            null,
            filemtime(TOROPLAY_DIR_PATH . 'resources/assets/css/font-awesome.css')
        );
    }

    static function enqueue_scripts(): void
    {
        wp_enqueue_script(
            '1c.js',
            TOROPLAY_DIR_URI . 'resources/assets/js/1c.js',
            null,
            filemtime(TOROPLAY_DIR_PATH . 'resources/assets/js/1c.js'),
            true
        );

        wp_enqueue_script(
            '1s.js',
            TOROPLAY_DIR_URI . 'resources/assets/js/1s.js',
            null,
            filemtime(TOROPLAY_DIR_PATH . 'resources/assets/js/1s.js'),
            true
        );

        wp_enqueue_script(
            'tp-pub.js',
            TOROPLAY_DIR_URI . 'resources/assets/js/tp-pub.js',
            null,
            filemtime(TOROPLAY_DIR_PATH . 'resources/assets/js/tp-pub.js'),
            true
        );

        $args = array(
            'url'       => admin_url('admin-ajax.php'),
            'nonce'     => wp_create_nonce('toroplay'),
            'version'   => TP_VERSION
        );

        wp_localize_script('tp-pub.js', 'toroplay', $args);
    }
}
