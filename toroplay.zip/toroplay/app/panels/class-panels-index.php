<?php

namespace TOROPLAY\panels;


class index
{
    public function __construct()
    {
        add_action('admin_menu', array($this, 'add_menus'));
        add_action('admin_menu', array($this, 'add_submenus'));

        add_action('admin_init', array($this, 'admin_init'));
    }

    function stp_api_select_field_1_render()
    {
        $options = get_option('stp_api_settings');

?>
        <fieldset>
            <legend class="screen-reader-text"><span>Ubicación de la barra lateral</span></legend>
            <p>
                <label>
                    <input name="stp_api_settings[tp_layout_sidebar]" type="radio" value="1" <?php checked($options['tp_layout_sidebar'] ?? null, 1); ?>> Izquierda
                </label>
                <br>
                <label>
                    <input name="stp_api_settings[tp_layout_sidebar]" type="radio" value="2" <?php checked($options['tp_layout_sidebar'] ?? null, 2); ?>> Derecha
                </label>
                <br>
                <label>
                    <input name="stp_api_settings[tp_layout_sidebar]" type="radio" value="3" <?php checked($options['tp_layout_sidebar'] ?? null, 3); ?>> Ninguno
                </label>
            </p>
        </fieldset>
<?php
    }

    function admin_init()
    {
        register_setting('stpPlugin', 'stp_api_settings');

        add_settings_section(
            'stp_api_stpPlugin_section',
            '',
            '',
            'stpPlugin'
        );

        add_settings_field(
            'tp_layout_sidebar',
            'Ubicación de la barra lateral',
            array($this, 'stp_api_select_field_1_render'),
            'stpPlugin',
            'stp_api_stpPlugin_section'
        );
    }

    function add_menus()
    {
        add_menu_page('Toroplay', 'TT Toroplay', 'manage_options', 'toroplay', array($this, 'fn_settings'), 'dashicons-screenoptions', 3);
    }

    function add_submenus()
    {
        add_submenu_page('toroplay', 'Ajustes', 'Ajustes', 'manage_options', 'toroplay');
        // add_submenu_page('toroplay', 'Utilidades', 'Utilidades', 'manage_options', 'my-menu2');
        add_submenu_page('toroplay', 'Homepage', 'Homepage', 'manage_options', 'toroplay-homepage', array($this, 'fn_homepage'));
        // add_submenu_page('toroplay', 'Base de datos', 'Base de datos', 'manage_options', 'my-menu4');
    }

    function fn_settings()
    {
        require_once TOROPLAY_DIR_PATH . 'app/panels/pages/panels-settings.php';
    }

    function fn_homepage()
    {
        require_once TOROPLAY_DIR_PATH . 'app/panels/pages/panels-home.php';
    }
}
