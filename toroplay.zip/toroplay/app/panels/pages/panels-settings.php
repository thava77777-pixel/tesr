<div class="wrap">
    <h1 class="wp-heading-inline">TT Toroplay</h1>
    <hr class="wp-header-end">

    <?php settings_errors(); ?>
    <form method="post" action="options.php" novalidate="novalidate">
        <table class="form-table" role="presentation">
            <tbody>
                <?php

                settings_fields('stpPlugin');
                do_settings_sections('stpPlugin');

                ?>
            </tbody>
        </table>
        <?php submit_button(); ?>
    </form>

    <!-- <form method="post" action="options.php" novalidate="novalidate">

        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row">Ubicación de la barra lateral</th>
                    <td>
                        <fieldset>
                            <legend class="screen-reader-text"><span>Ubicación de la barra lateral</span></legend>
                            <p>
                                <label><input name="rss_use_excerpt" type="radio" value="0" checked="checked"> Izquierda</label><br>
                                <label><input name="rss_use_excerpt" type="radio" value="1"> Derecha</label><br>
                                <label><input name="rss_use_excerpt" type="radio" value="3"> Ninguno</label>
                            </p>
                        </fieldset>
                    </td>
                </tr>

                <tr>
                    <th scope="row">Opciones de diseño</th>
                    <td>
                        <fieldset>
                            <legend class="screen-reader-text"><span>Opciones de diseño</span></legend>
                            <label for="default_pingback_flag">
                                <input name="default_pingback_flag" type="checkbox" id="default_pingback_flag" value="1" checked="checked">
                                Eliminar los bordes redondeados</label>
                            <br>
                            <label for="default_ping_status">
                                <input name="default_ping_status" type="checkbox" id="default_ping_status" value="open">
                                A todo lo ancho</label>
                            <br>
                            <label for="default_comment_status">
                                <input name="default_comment_status" type="checkbox" id="default_comment_status" value="open">
                                En caja </label>
                            <br>
                            <p class="description">(Estos ajustes pueden ser anulados en paginas individuales)</p>
                        </fieldset>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="posts_per_page">Número máximo de temporadas a mostrar en el sitio</label></th>
                    <td>
                        <input name="posts_per_page" type="number" step="1" min="1" id="posts_per_page" value="15" class="small-text"> temporadas
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="posts_per_page">Número máximo de episodios a mostrar en el sitio</label></th>
                    <td>
                        <input name="posts_per_page" type="number" step="1" min="1" id="posts_per_page" value="15" class="small-text"> episodios
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="posts_per_page">Número máximo de peliculas a mostrar en el sitio</label></th>
                    <td>
                        <input name="posts_per_page" type="number" step="1" min="1" id="posts_per_page" value="15" class="small-text"> peliculas
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="posts_per_page">Número máximo de series a mostrar en el sitio</label></th>
                    <td>
                        <input name="posts_per_page" type="number" step="1" min="1" id="posts_per_page" value="15" class="small-text"> series
                    </td>
                </tr>

            </tbody>
        </table>
    </form> -->
</div>