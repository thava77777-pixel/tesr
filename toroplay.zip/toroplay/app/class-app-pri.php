<?php

namespace TOROPLAY\app;

class pri
{

    function __construct()
    {
        add_action('admin_enqueue_scripts', array($this, 'enqueue_styles'), 10);
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'), 10);
    }

    static function enqueue_styles()
    {
        //
    }

    static function enqueue_scripts()
    {
        wp_enqueue_script(
            array(
                'jquery-ui-core',
                'jquery-ui-sortable'
            )
        );
    }
}
